import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import vm from 'node:vm';import {stripTypeScriptTypes} from 'node:module';
import crypto from 'node:crypto';
const root=process.env.KAD1_TARGET_ROOT||process.cwd();
const source=process.env.KAD1_SOURCE_ROOT||root;
const contextValue={purpose:{namespace:'test',code:'display',version:'1'},scope:{project:'one'}};
async function load(rel,session,query=()=>[]){
 const calls=[];const sandbox=vm.createContext({console,Buffer,process:{env:{MOHEN_G5_CONTEXTS:JSON.stringify({visual_stage:contextValue,agent:contextValue})}},Date,JSON,Set,Object,Number,Array,RegExp,Error});
 const cache=new Map();
 const synthetic=(key,values)=>{const m=new vm.SyntheticModule(Object.keys(values),function(){for(const [k,v]of Object.entries(values))this.setExport(k,v);},{context:sandbox,identifier:key});return m;};
 async function module(key){
  if(cache.has(key))return cache.get(key);
  let m;
  if(key==='@mohen/data-access')m=synthetic(key,{queryRows:async(sql,p)=>{calls.push({sql,p});return query(sql,p,calls.length);},queryValue:async(sql,p)=>{calls.push({sql,p});const rows=query(sql,p,calls.length);return rows[0]?Object.values(rows[0])[0]:null;},run:async(sql,p)=>{calls.push({sql,p});return true;}});
  else if(key==='next/server')m=synthetic(key,{NextRequest:class{},NextResponse:{json:(body,options={})=>({body,status:options.status||200})}});
  else if(key==='next/headers')m=synthetic(key,{cookies:async()=>({get:()=>({value:'signed-token'})})});
  else if(key.endsWith('/session'))m=synthetic(key,{getSession:async()=>session});
  else if(key.endsWith('/auth'))m=synthetic(key,{OPERATOR_COOKIE:'mohen_role',getSessionUser:async()=>session,isOperator:async()=>!!session?.r.includes('operator')});
  else if(key.endsWith('/studio-creation'))m=synthetic(key,{generateDirectorPlans:async()=>null,generateBeats:async()=>[],generateWorkPanels:async()=>({voiceover:{full:'saved'}})});
  else if(key.endsWith('/guard'))m=synthetic(key,{guardRoute:async()=>null});
  else if(key==='node:crypto')m=synthetic(key,{default:crypto,randomUUID:crypto.randomUUID});
  else {
   let file=key;search:for(const base of [root,source])for(const suffix of ['', '.ts','.mjs']){const candidate=path.join(base,key+suffix);if(fs.existsSync(candidate)&&fs.statSync(candidate).isFile()){file=candidate;break search;}}
   if(!path.isAbsolute(file))throw new Error('missing test module '+key);
   let text=fs.readFileSync(file,'utf8');if(file.endsWith('.ts'))text=stripTypeScriptTypes(text);
   m=new vm.SourceTextModule(text,{context:sandbox,identifier:key});
  }
  cache.set(key,m);
  if(m instanceof vm.SourceTextModule)await m.link(async(spec,parent)=>module(spec.startsWith('.')?path.posix.normalize(path.posix.join(path.posix.dirname(parent.identifier),spec)):spec));
  return m;
 }
 const m=await module(rel);await m.evaluate();return {api:m.namespace,calls};
}
const user={uid:'11111111-1111-1111-1111-111111111111',r:['creator']};
test('version list refuses anonymous access without issuing SQL',async()=>{
 const {api,calls}=await load('apps/web/app/api/studio/works/[id]/revisions/route.ts',null);
 const r=await api.GET({}, {params:Promise.resolve({id:'work'})});assert.equal(r.status,401);assert.equal(calls.length,0);
});
test('version list is pure read with owner bound at SQL boundary',async()=>{
 const {api,calls}=await load('apps/web/app/api/studio/works/[id]/revisions/route.ts',user,()=>[{revision_no:'1'}]);
 const r=await api.GET({}, {params:Promise.resolve({id:'work'})});assert.equal(r.status,200);assert.equal(calls[0].p.uid,user.uid);assert.match(calls[0].sql,/owner_user_id/);assert.doesNotMatch(calls[0].sql,/insert|update|delete/i);assert.equal(typeof api.POST,'function');
});
test('specific revision rejects malformed revision before querying',async()=>{
 const {api,calls}=await load('apps/web/app/api/studio/works/[id]/revisions/[rev]/route.ts',user);
 const r=await api.GET({}, {params:Promise.resolve({id:'work',rev:'1x'})});assert.equal(r.status,400);assert.equal(calls.length,0);
});
test('snapshot panel returns saved revision data, not regenerated plan',async()=>{
 const {api,calls}=await load('apps/web/app/api/studio/works/[id]/revisions/[rev]/panels/[panel]/route.ts',user,()=>[{revision_id:'r',content:{panels:{voiceover:{full:'saved'}}}}]);
 const r=await api.GET({}, {params:Promise.resolve({id:'work',rev:'1',panel:'voiceover'})});assert.equal(r.status,200);assert.equal(r.body.value.full,'saved');assert.equal(calls[0].p.uid,user.uid);
});
test('old revision without panel snapshot is explicitly unavailable',async()=>{
 const {api}=await load('apps/web/app/api/studio/works/[id]/revisions/[rev]/panels/[panel]/route.ts',user,()=>[{revision_id:'r',content:{}}]);
 const r=await api.GET({}, {params:Promise.resolve({id:'work',rev:'1',panel:'voiceover'})});assert.equal(r.status,404);assert.equal(r.body.reason,'panel_snapshot_unavailable');
});
test('stage status does not claim delegated/researched/directed when records are absent',async()=>{
 const {api}=await load('apps/web/lib/publication.ts',user);
 const s=await api.getWorkStageStatus('work');for(const k of ['delegated','researched','directed','revisioned'])assert.equal(s[k],false);
});
test('publication progress derives only the matching work records',async()=>{
 const {api,calls}=await load('apps/web/lib/publication.ts',user,sql=>sql.includes('research_tasks')?[{status:'running'}]:[{content:{director_plan_ref:{id:'p'}}}]);
 const s=await api.getWorkStageStatus('work');assert.equal(s.delegated,true);assert.equal(s.researched,false);assert.equal(s.directed,true);assert.ok(calls.every(c=>c.p.wid==='work'));
});
test('legacy provenance strings cannot authorize publication',async()=>{
 const {api}=await load('apps/web/lib/publication.ts',user,()=>[{revision_id:'r',content:{beats:[{provenanceRefs:['old source']}],rights_acknowledged:true}}]);
 const r=await api.checkPublishEligibility('work');assert.equal(r.ok,false);assert.equal(r.reason,'versioned_qualification_refs_required');
});
test('private attachment endpoint never writes public files while storage is unbound',async()=>{
 const {api,calls}=await load('apps/web/app/api/studio/attachments/route.ts',user);
 const r=await api.POST({cookies:{get:()=>({value:'signed-token'})}});assert.equal(r.status,423);assert.equal(calls.length,0);
});
test('selected plan panels do not reference a missing work parameter',async()=>{
 const {api}=await load('apps/web/lib/studio-director.ts',user,()=>[{selected:'A',plan_a:{},facts:[],beats:[{title:'saved'}]}]);
 const panel=await api.getWorkPanels('plan');assert.equal(panel.voiceover.full,'saved');
});
const revisionId='11111111-1111-1111-1111-111111111111';
const qualifiedContent={beats:[{provenanceRefs:['source']}],rights_acknowledged:true,qualification_refs:[{qualification_ref:revisionId,artifact_ref:{type:'story_seed',id:revisionId,revision:'1'},consumer:'visual_stage',...contextValue}]};
const publicationRows=(sql)=>{
 if(sql.includes('publication.publication_schedules'))return [{schedule_id:'schedule',work_id:'work'}];
 if(sql.includes('control.work_publication_decisions')&&!sql.includes('with work_lock'))return [{decision:'approved',reviewer:'22222222-2222-2222-2222-222222222222',revision_id:revisionId}];
 if(sql.includes("'reviewer'=any"))return [];
 if(sql.includes('select email from public.users'))return [{email:'publisher@example.test'}];
 if(sql.includes('select revision_id::text as revision_id, content'))return [{revision_id:revisionId,content:qualifiedContent}];
 return [{revision_id:revisionId,one:1}];
};
test('withdrawn reviewer authority blocks an otherwise approved publication',async()=>{
 const {api}=await load('apps/web/lib/publication.ts',user,publicationRows);
 const result=await api.checkPublishEligibility('work',user.uid);assert.equal(result.ok,false);assert.equal(result.reason,'reviewer_authority_revoked');
});
test('due schedules publish under the supplied currently authorized actor, not a magic scheduler identity',async()=>{
 const {api,calls}=await load('apps/web/lib/publication.ts',user,sql=>sql.includes("'reviewer'=any")?[{user_id:'22222222-2222-2222-2222-222222222222'}]:publicationRows(sql));
 await api.processDueSchedules(user.uid);const publish=calls.find(c=>c.sql.includes('with work_lock'));assert.ok(publish);assert.equal(publish.p.by,user.uid);
});
