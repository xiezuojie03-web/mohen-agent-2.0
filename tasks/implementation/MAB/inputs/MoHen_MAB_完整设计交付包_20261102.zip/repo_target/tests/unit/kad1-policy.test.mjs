import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const root=process.env.KAD1_TARGET_ROOT || process.cwd();
const file=path.join(root,'apps/web/lib/kad1-policy.mjs');
test('KAD1 needs a real consumption/snapshot policy target',()=>assert.ok(fs.existsSync(file),'missing implementation target'));
const policy=fs.existsSync(file)?await import(pathToFileURL(file)):null;
test('missing, malformed or broad consumer context cannot grant public consumption',{skip:!policy},()=>{
 for(const v of [undefined,'bad','{}','{"visual_stage":{"purpose":{},"scope":{}}}'])assert.equal(policy.consumerContext('visual_stage',v),null);
});
const context={purpose:{namespace:'test',code:'display',version:'1'},scope:{project:'one'}};
test('explicit consumer context remains scoped',{skip:!policy},()=>{
 assert.deepEqual(policy.consumerContext('visual_stage',JSON.stringify({visual_stage:context})),context);
 assert.equal(policy.consumerContext('agent',JSON.stringify({visual_stage:context})),null);
});
const rid='11111111-1111-1111-1111-111111111111';
const reference={qualification_ref:rid,artifact_ref:{type:'story_seed',id:rid,revision:'rev-1'},consumer:'visual_stage',...context};
test('legacy citation strings and unversioned references do not become G5',{skip:!policy},()=>{
 for(const refs of [[],['some source'],[{...reference,artifact_ref:{type:'story_seed',id:rid}}]])assert.equal(policy.qualificationRefs({qualification_refs:refs},context,'visual_stage'),null);
 assert.deepEqual(policy.qualificationRefs({qualification_refs:[reference]},context,'visual_stage'),[reference]);
});
test('wrong purpose or consumer cannot reuse a qualification',{skip:!policy},()=>{
 assert.equal(policy.qualificationRefs({qualification_refs:[{...reference,consumer:'agent'}]},context,'visual_stage'),null);
 assert.equal(policy.qualificationRefs({qualification_refs:[{...reference,purpose:{...context.purpose,code:'download'}}]},context,'visual_stage'),null);
});
test('panel lookup uses saved revision snapshot only',{skip:!policy},()=>{
 assert.equal(policy.savedPanel({plan:{angle:'draft'}},'visualStyle'),null);
 const content={panels:{visualStyle:{style:'ink'}}};assert.deepEqual(policy.savedPanel(content,'visualStyle'),{style:'ink'});
 assert.equal(policy.savedPanel(content,'__proto__'),null);
});
test('revision and playhead parsing reject malformed or unbounded input',{skip:!policy},()=>{
 for(const v of ['1x','0','-2','1.1','9999999999999999999'])assert.equal(policy.revisionNumber(v),null);
 assert.equal(policy.revisionNumber('3'),3);
 for(const v of [-1,NaN,Infinity,'1'])assert.equal(policy.validPlayhead(v),false);
 assert.equal(policy.validPlayhead(4.5),true);
});
test('media requires a current licensed versioned reference; no-media requires acknowledgement',{skip:!policy},()=>{
 assert.equal(policy.mediaPermitted({media:[]},[reference]),false);
 assert.equal(policy.mediaPermitted({media:[],rights_acknowledged:true},[reference]),true);
 assert.equal(policy.mediaPermitted({media:[{license:'cc'}]},[reference]),false);
 assert.equal(policy.mediaPermitted({media:[{license:'cc',rights_status:'cleared',artifact_ref:reference.artifact_ref}]},[reference]),true);
 assert.equal(policy.mediaPermitted({media:[{license:'cc',rights_status:'cleared',artifact_ref:reference.artifact_ref,valid_until:'2000-01-01'}]},[reference]),false);
});
test('qualified SQL checks precise audit, artifact version and current Gate function',{skip:!policy},()=>{
 const sql=policy.qualifiedContentSql('r','visual_stage');
 for(const term of ['qualification_allows','artifact_revision','qualification_ref','G5','purpose_namespace','purpose_code','purpose_version'])assert.ok(sql.includes(term),term);
 assert.throws(()=>policy.qualifiedContentSql('user supplied','agent'));
});

test('review queue must match approved decision to the exact submitted revision',()=>{
 const src=fs.readFileSync(path.join(root,'apps/web/lib/publication.ts'),'utf8');
 assert.match(src,/d\.work_id = w\.work_id and d\.revision_id=r\.revision_id and d\.decision = 'approved'/);
});
test('reviewer disabling and operator role change require designated authority',()=>{
 const sql=fs.readFileSync(path.join(root,'supabase/migrations/202611020920_kad1_account_transactions.sql'),'utf8');
 assert.match(sql,/p_status='disabled' and 'reviewer'=any\(old_roles\) and not 'reviewer'=any\(actor_roles\)/);
 const gate=fs.readFileSync(path.join(root,'apps/web/lib/gate-review.ts'),'utf8');
 assert.doesNotMatch(gate,/注册即获 reviewer/);
});

test('new Repo mirrors have canonical root route and six MHKA chapters',()=>{
 const agents=fs.readFileSync(path.join(root,'AGENTS.md'),'utf8');
 assert.match(agents,/MHKA-00/);assert.match(agents,/MHKA-05/);
 for(let i=0;i<6;i++)assert.ok(fs.readdirSync(path.join(root,'governance/mhka')).some(v=>v.startsWith('MHKA-0'+i+'_')));
});
test('production protocol is under MHKA while old C is historical until atomically switched',()=>{
 const p=fs.readFileSync(path.join(root,'specs/data-production/MoHen_Data_Production_Protocol.md'),'utf8');
 assert.match(p,/MHKA-03/);assert.match(p,/MHKA-04/);assert.match(p,/C0—C4是本协议的历史研究来源/);
});
test('all 63 methods are bound to precisely the current production protocol SHA',async()=>{
 const crypto=await import('node:crypto');
 const raw=fs.readFileSync(path.join(root,'specs/data-production/MoHen_Data_Production_Protocol.md'));
 const hash=crypto.createHash('sha256').update(raw).digest('hex');
 const binding=JSON.parse(fs.readFileSync(path.join(root,'specs/data-production/method-binding-contract.json'),'utf8'));
 assert.equal(binding.methods.length,63);
 for(const m of binding.methods)assert.equal(m.definition.source_sha256,hash);
});
test('standalone reviewer cannot mutate account ACL or be silently auto-granted',()=>{
 const api=fs.readFileSync(path.join(root,'apps/web/app/api/admin/acl/route.ts'),'utf8');
 const sql=fs.readFileSync(path.join(root,'supabase/migrations/202611020920_kad1_account_transactions.sql'),'utf8');
 assert.match(api,/session\.r\.includes\("operator"\)/);
 assert.match(sql,/operator_required/);
 assert.doesNotMatch(sql,/or \(p_roles is not null and 'reviewer'/);
});
test('published work is not automatically promoted into world or read_model knowledge',()=>{
 const p=fs.readFileSync(path.join(root,'apps/web/lib/publication.ts'),'utf8');
 assert.doesNotMatch(p,/await reflowWorkToAssets\(/);
});
test('visual consumption uses parameterized escaped scope and explicit license',()=>{
 const p=fs.readFileSync(path.join(root,'apps/web/lib/read-model-bridge.ts'),'utf8');
 assert.match(p,/topicParams/);assert.match(p,/escape '#'/);assert.match(p,/v\.license\.length > 0/);
});
test('failed revocation API reports blocked status instead of HTTP 200 success',()=>{
 const p=fs.readFileSync(path.join(root,'apps/web/app/api/admin/rights/invalidate/route.ts'),'utf8');
 assert.match(p,/result\.ok \? 200/);
 const g=fs.readFileSync(path.join(root,'apps/web/lib/gate-revoke.ts'),'utf8');
 assert.match(g,/invalid_object_id/);assert.match(g,/invalid_object_type/);
});
test('Repo normative contracts replace research-stage KAD1-C implicit runtime dependency',()=>{
 const m=fs.readFileSync(path.join(root,'governance/mhka/MHKA-02_Humanistic_Product_and_Experience.md'),'utf8');
 assert.match(m,/H1_H2_H3_AND_COMPONENTS_CONTRACT/);
 assert.doesNotMatch(m,/`KAD1-C_H1-H2-H3与I组件体验方法合同_现行\.md`/);
});
