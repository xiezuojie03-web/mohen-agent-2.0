# 墨痕｜OWNERSHIP_MAP（MHKA目标代际）

> 设计镜像声明：本文件是可交付的**完整目标规范正文**，仅当经Owner授权的工程原子切换及测试通过后在仓库生效。Library状态不等于GitHub/生产已生效；任何未授权操作继续HOLD。

## 0｜工程目录规范：按仓库真实路径，不按阶段另造项目树

````text
mohen-agent-2.0/
├── AGENTS.md / CURRENT.md / OWNERSHIP_MAP.md / DATA_PRODUCTION_MAP.md
├── governance/
│   ├── mhka/MHKA-00_Governance_Charter.md ... MHKA-05_Software_Engineering_and_Operations.md
│   └── archive/             # 旧C0—C4授权后归档，仅历史取证
├── specs/                   # 唯一有效Contract/Protocol/Registry/Schema
│   ├── data-production/     # 生产、资格、持久化与绑定
│   ├── experience-ui/       # H/I专业创作与组件方法
│   └── requirements/        # 85 API、152动作机器合同及索引
├── skills/                  # 一个目录一个Skill，身份/状态在Manifest中
├── pipelines/               # 单一正式生产run入口、Adapter/Executor
├── packages/                # Agent/Experience/数据访问复用代码
├── apps/                    # Web工作台与服务接口
├── supabase/                # 迁移及可验证回滚
├── tests/ verification/ scripts/
├── tasks/                   # 工程实施计划和回执，不拥有架构权威
└── decisions/ archive/ legacy/ data/
````

## 1｜唯一Owner层次

- `governance/mhka/`负责MHKA-00—05上位语义；本目录不得放旧C0—C4 active副本。
- `specs/`负责其被授权的详细合同（含R4.3资产、R4/CAP能力、H/I体验、D/L/G、DB安全与API），不自立第二套宪章。
- `skills/`声明专业能力的执行入口；Stage、Skill、Tool、Method、Registry、Adapter各有独立身份。
- `pipelines/data-production/run.mjs`仍是唯一D00—D05正式生产入口，不能因KAD1生成第二条生产系统。
- `apps/web/`的Studio、Admin、WATCH按工程API和知识资格消费；EXP持续保留未来目标。
- `packages/data-access/`实施读写物理分权与版本一致性；实际SQL/RLS只由授权工程操作。
- `tests/verification/`承载可重跑正反验收，DesignReady与LiveReady分别记录。

## 2｜Library镜像与真实仓库

Library中`04_工程规范与Codex接入/repo_target/`是**变更文件镜像**，本目录本身不是工程仓库；其中仓库根文件直接位于`repo_target/`，下级保持同一相对路径，只存经审查确定需CREATE/REVISE/REPLACE/ARCHIVE的目标文件，不拷贝KEEP或数据。
`04/00_总览/`存索引、来源、迁移、审查和回滚证据，**不进入工程仓库**。旧专项研究与过时K3候选没有规范权力。

## 3｜激活顺序与最低验收

先定向差分现存main代码与历史K3变更，保护现有Gate仓储、SQL迁移和Studio已修复路径；核MHKA与新合同完整可读→正反用例→授权原子切换→旧C文件只读归档及可回退。
原C合同和历史规范在未切换前仍按实际工程权威工作，切换后只有MHKA拥有上位定义。`CURRENT.md`仍独占真实状态，不以本图/设计目标证明运行PASS。
