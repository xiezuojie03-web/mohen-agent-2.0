import {NextResponse} from "next/server";
import {queryRows} from "@mohen/data-access";
import {consumerContext,contextParams} from "../../../../../lib/kad1-policy.mjs";
export const runtime='nodejs';export const dynamic='force-dynamic';
export async function GET(_req:Request,{params}:{params:Promise<{id:string}>}){
 const context=consumerContext('visual_stage');if(!context)return NextResponse.json({ok:false,reason:'qualification_context_required'},{status:423});
 const {id}=await params;const rows=await queryRows(`select e.evidence_pointer_id::text as id,e.display_locator,e.display_excerpt from read_model.evidence_pointers e
 where e.evidence_pointer_id=:'id' and exists(select 1 from control.qualification_current q join control.gate_audits g on g.gate_audit_id=q.gate_audit_id
 where q.gate_code='G5' and q.object_type='evidence_pointer' and q.object_id=e.evidence_pointer_id
 and control.qualification_allows(g.gate_audit_id,'visual_stage',:'purpose_namespace',:'purpose_code',:'purpose_version',:'allowed_scope'::jsonb))`,{id,...contextParams(context)});
 if(!rows.length)return NextResponse.json({ok:false,reason:'not_found'},{status:404});return NextResponse.json({ok:true,evidence:rows[0]});
}
