import { queryRows } from "@mohen/data-access";
import { getSession } from "../../../../../../../lib/session";
import { revisionNumber } from "../../../../../../../lib/kad1-policy.mjs";
import { NextResponse } from "next/server";
import { reviseBeat } from "../../../../../../../lib/studio-director";
import { guardRoute } from "../../../../../../../lib/guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// POST /api/studio/works/:id/revisions/:rev —— 局部改稿（CAS 校验 expected revision no）
export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string; rev: string }> }
) {
  const denied = await guardRoute(params, "publication.works");
  if (denied) return denied;
  const { id, rev } = await params;
  let beat_diff: unknown;
  try {
    const body = (await req.json()) as { beat_diff?: unknown };
    beat_diff = body.beat_diff;
  } catch {
    return NextResponse.json({ ok: false, reason: "bad_request" }, { status: 400 });
  }
  if (!Array.isArray(beat_diff)) {
    return NextResponse.json({ ok: false, reason: "beat_diff_required" }, { status: 400 });
  }
  const expected = Number(rev);
  if (!Number.isInteger(expected)) {
    return NextResponse.json({ ok: false, reason: "invalid_revision" }, { status: 400 });
  }
  const result = await reviseBeat(
    id,
    expected,
    beat_diff as Array<{ index: number; patch: Record<string, unknown> }>
  );
  if (!result) return NextResponse.json({ ok: false, reason: "no_revision" }, { status: 404 });
  if (result.conflict) {
    return NextResponse.json({ ok: false, reason: "version_conflict", revision_no: result.revisionNo }, { status: 409 });
  }
  return NextResponse.json({ ok: true, revision_id: result.revisionId, revision_no: result.revisionNo });
}

export async function GET(_req: Request, { params }: { params: Promise<{ id: string; rev?: string }> }) {
 const session=await getSession();if(!session)return NextResponse.json({ok:false,reason:'login_required'},{status:401});
 const {id,rev}=await params;
 const n=revisionNumber(rev);if(n===null)return NextResponse.json({ok:false,reason:'invalid_revision'},{status:400});
 const rows=await queryRows(`select r.revision_id::text as revision_id,r.revision_no::text as revision_no,
 r.title,r.description,r.status,r.created_at::text as created_at,r.content
 from publication.work_revisions r join publication.works w on w.work_id=r.work_id
 where w.work_id=:'wid' and w.owner_user_id=:'uid' and r.revision_no=:'rev' order by r.revision_no desc`, {wid:id,uid:session.uid ,rev:n});
 if(!rows.length)return NextResponse.json({ok:false,reason:'not_found'},{status:404});return NextResponse.json({ok:true,revision:rows[0]});
}
