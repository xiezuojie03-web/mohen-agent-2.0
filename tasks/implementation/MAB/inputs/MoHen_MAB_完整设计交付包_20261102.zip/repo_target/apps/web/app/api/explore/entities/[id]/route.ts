import {NextResponse} from "next/server";
import {guardRoute} from "../../../../../lib/guard";
export const runtime='nodejs';export const dynamic='force-dynamic';
export async function GET(_req:Request,{params}:{params:Promise<{id:string}>}){
 const denied=await guardRoute(params,null);if(denied)return denied;
 return NextResponse.json({ok:false,reason:'qualified_projection_required'},{status:423});
}
