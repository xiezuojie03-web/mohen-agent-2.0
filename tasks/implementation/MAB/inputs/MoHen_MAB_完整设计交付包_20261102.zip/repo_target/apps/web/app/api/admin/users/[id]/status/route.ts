import {NextRequest,NextResponse} from "next/server";
import {queryRows} from "@mohen/data-access";
import {OPERATOR_COOKIE,getSessionUser} from "../../../../../../lib/auth";
export const runtime='nodejs';export const dynamic='force-dynamic';
export async function POST(req:NextRequest,{params}:{params:Promise<{id:string}>}){
 const token=req.cookies.get(OPERATOR_COOKIE)?.value;const session=await getSessionUser(token);
 if(!session||!(session.r.includes("operator")))return NextResponse.json({ok:false,reason:'forbidden'},{status:403});
 let body:Record<string,unknown>;try{body=await req.json();}catch{return NextResponse.json({ok:false,reason:'bad_request'},{status:400});}
 const {id}=await params;
 if(typeof id!=='string'||!/^[0-9a-f-]{36}$/i.test(id))return NextResponse.json({ok:false,reason:'invalid_id'},{status:400});
 if(body.status!=="active"&&body.status!=="disabled")return NextResponse.json({ok:false,reason:"invalid_status"},{status:400});
 const rows=await queryRows(`with context as materialized(select set_config('mohen.session_token',:'token',true))
 select control.kad1_change_account(:'actor'::uuid,:'id'::uuid,:'roles'::text[],:'status') as reason from context`,
 {token,actor:session.uid,id,roles:null,status:String(body.status)});
 const reason=String(rows[0]?.reason||'unavailable');if(reason!=='ok')return NextResponse.json({ok:false,reason},{status:reason==='not_found'?404:reason.startsWith('last_')?409:reason.startsWith('invalid_')?400:403});
 return NextResponse.json({ok:true,user_id:id,status:body.status});
}
