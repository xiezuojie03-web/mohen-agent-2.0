// apps/web/lib/gate-review.ts — 作品出版Reviewer签核（与史学G0—G5独立）。
//
// 独立 Reviewer 是独立于 Operator / Producer 的签核身份：只有它签署「知识引用 + 媒体权利」
// 通过后，Operator 才能发布作品（CR-04：Operator 不得代签知识 Gate）。
//
// 补缺施工第四步：Reviewer 身份从「静态 REVIEWER_KEY 密钥」升级为「登录用户中 roles 含 reviewer 的账号」
// 角色配置必须由授权管理和新鲜会话确认，不能凭特定邮箱注册自动授予 Reviewer）。签核记录可审计 reviewer 身份。
import { queryRows, queryValue, run } from "@mohen/data-access";
import { hasRole } from "./auth";

export function isReviewerConfigured(): boolean {
  // Reviewer 来自用户角色，无需外部密钥；始终可用。
  return true;
}

/** 校验 token 是否为独立 Reviewer（roles 含 reviewer）。 */
export async function verifyReviewer(token: string | undefined | null): Promise<boolean> {
  return hasRole(token, "reviewer");
}

/** 独立 Reviewer 签核作品发布（approved / rejected），reviewer 传真实标识（邮箱/user_id）。 */
export async function signWorkPublication(
  workId: string,
  revisionId: string | null,
  decision: "approved" | "rejected",
  reviewer: string,
  note?: string
): Promise<{ ok: boolean; reason?: string }> {
  const work = await queryValue(
    "select work_id::text from publication.works where work_id = :'id'",
    { id: workId }
  );
  if (!work) return { ok: false, reason: "work_not_found" };

  const rid=revisionId ?? await queryValue("select revision_id::text from publication.work_revisions where work_id=:'wid' and status='submitted' order by revision_no desc limit 1",{wid:workId});
  if(!rid)return {ok:false,reason:'submitted_revision_required'};
  const rows=await queryRows(`insert into control.work_publication_decisions(work_id,revision_id,decision,reviewer,note)
    select r.work_id,r.revision_id,:'dec',:'reviewer',:'note' from publication.work_revisions r
    where r.work_id=:'wid' and r.revision_id=:'rid' and r.status='submitted' returning revision_id::text as revision_id`,
    {wid:workId,rid,dec:decision,reviewer,note:note??null});
  return rows.length?{ok:true}:{ok:false,reason:'submitted_revision_required'};
}

/** 读某作品最新的独立 Reviewer 决策（无决策返回 null）。 */
export async function getLatestWorkDecision(workId: string): Promise<string | null> {
  const rows = await queryRows(
    "select decision from control.work_publication_decisions where work_id = :'id' order by reviewed_at desc limit 1",
    { id: workId }
  );
  return rows.length ? String(rows[0].decision) : null;
}
