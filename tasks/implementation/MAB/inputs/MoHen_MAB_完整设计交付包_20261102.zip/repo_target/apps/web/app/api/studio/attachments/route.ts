import {NextRequest,NextResponse} from "next/server";
import {OPERATOR_COOKIE,getSessionUser} from "../../../../lib/auth";
export const runtime='nodejs';export const dynamic='force-dynamic';
export async function POST(req:NextRequest){
 const session=await getSessionUser(req.cookies.get(OPERATOR_COOKIE)?.value);
 if(!session)return NextResponse.json({ok:false,reason:'auth_required'},{status:401});
 return NextResponse.json({ok:false,reason:'private_storage_binding_required',retryable:false},{status:423});
}
