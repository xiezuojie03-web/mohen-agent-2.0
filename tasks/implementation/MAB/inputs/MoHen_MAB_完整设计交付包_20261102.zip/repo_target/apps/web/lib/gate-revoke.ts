import {queryRows} from "@mohen/data-access";
export interface RevokeInput {objectType:string;objectId:string;reason?:string;sessionToken?:string}
export interface RevokeResult {ok:boolean;reason?:string;invalidatedGates:number;invalidationEventId?:string;blockingRequestId?:string}
export async function revokeGate(input:RevokeInput):Promise<RevokeResult>{
 if(!input.sessionToken)return {ok:false,reason:'verified_session_required',invalidatedGates:0};
 if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(input.objectId))return {ok:false,reason:'invalid_object_id',invalidatedGates:0};
 if(!/^[a-z][a-z_]{0,63}$/.test(input.objectType))return {ok:false,reason:'invalid_object_type',invalidatedGates:0};
 if(input.objectType==='asset')return {ok:false,reason:'asset_identity_mapping_required',invalidatedGates:0};
 const rows=await queryRows(`with context as materialized(select set_config('mohen.session_token',:'token',true))
 select control.request_consumption_block(:'type',:'id'::uuid,:'reason')::text as id from context`,
 {token:input.sessionToken,type:input.objectType,id:input.objectId,reason:input.reason||'rights_revoked'});
 return rows.length?{ok:true,invalidatedGates:0,blockingRequestId:rows[0].id}:{ok:false,reason:'block_not_recorded',invalidatedGates:0};
}
