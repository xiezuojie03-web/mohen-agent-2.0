# 墨痕 MoHen｜工程仓库权威入口（MHKA目标代际）

> 设计镜像声明：本文件是可交付的**完整目标规范正文**，仅当经Owner授权的工程原子切换及测试通过后在仓库生效。Library状态不等于GitHub/生产已生效；任何未授权操作继续HOLD。

## 1｜唯一权威与严格生效边界

本文件为工程迁移的完整目标入口；在原子切换得到Owner授权并完成读链/安全回归**之前**，GitHub实际`AGENTS.md`对旧C0—C4的路由仍有效，不能在Library单独声明已切换。

**切换完成后**，仓库根目录按下列优先级读取：

1. `CURRENT.md`：当前部署/代码/测试/已签运行事实和HOLD；它是状态源而非提高权限的宪章。
2. 本 `AGENTS.md`：仅提供路径和优先级，不独立定义产品或方法。
3. `governance/mhka/MHKA-00_Governance_Charter.md` 至 `MHKA-05_Software_Engineering_and_Operations.md`：六份唯一设计架构权威，分别负责治理、价值、体验、知识、Agent专业能力、工程实现。
4. `specs/FOUNDATION.md`→相应唯一专业合同→源文件/接口/测试：下位规范不得修改其语义Owner。
5. `OWNERSHIP_MAP.md`：仓库相对路径和职能分工；`DATA_PRODUCTION_MAP.md`：正式生产入口。

## 2｜专业合同路由（正文不是旧文件索引）

| 范围 | 本代唯一专业入口 |
|---|---|
| D00—D05/L0—L5、63方法 | `specs/data-production/MoHen_Data_Production_Protocol.md` |
| G0—G5及独立Reviewer/资格 | `specs/data-production/gates/G0-G5_MACHINE_GATE_CONTRACT_V3.0.md` |
| 13类知识/研究/作品资产与R4.3 | `specs/KNOWLEDGE_ASSET_LIFECYCLE_CONTRACT.md` |
| R4/CAP、19 Skill、模型工具路由 | `specs/AGENT_PROFESSIONAL_CAPABILITIES_CONTRACT.md` |
| H1/H2/H3、19组件、人文叙事 | `specs/experience-ui/H1_H2_H3_AND_COMPONENTS_CONTRACT.md` |
| 受控Agent研究接口 | `specs/AGENT_CONTRACT.md` |
| ExperienceState、Action/Patch、双组件 | `specs/EXPERIENCE_CONTRACT.md` |
| 数据对象与物理绑定 | `specs/DATA_CONTRACT.md` + `specs/data-production/PERSISTENCE_BINDING_CONTRACT.md` |
| 安全、ACL/RLS、发布分权 | `specs/SECURITY_ACCESS_CONTRACT.md` |
| API/工具与85、152机器输入 | `specs/API_TOOL_CONTRACT.md`、`specs/requirements/` |
| Registry/Skill与实际运行 | `specs/data-production/production-registry.json`、`method-binding-contract.json`、`skills/`、`pipelines/data-production/` |

## 3｜仍然必须保持的真实工程HOLD

专业Gate的策略签发与真实RLS、SEC-01、Studio双主体真实混合运行、长久资产复用、152项交互实测均不得因本文件存在标PASS。不得对GitHub真实远端、数据库、Vercel等执行未授权迁移。设计/代码/隔离测试/线上运行/Owner签收分开记录。

## 4｜代际原子切换与回滚

旧`governance/C0—C4`不能与新MHKA并行修改同一权威；施工中先验证六份新章程和合同及其全部目标文件，随后经授权进行原子路由切换、旧C0—C4只读归档。若切换失败，则回退入口到历史合法提交并保留审计及撤权，不能复活过期资格。

**设计审查基线：** `main@db21cefcc09c6bcb5d7e3fca16d100cc0accd13d`，发布前必须读取实际HEAD、工作树、云端环境并三方差分。
