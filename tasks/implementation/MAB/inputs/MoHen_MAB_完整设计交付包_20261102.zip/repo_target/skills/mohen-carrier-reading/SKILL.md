---
name: mohen-carrier-reading
description: Use when carrying out MoHen D01 L1 production tasks under the six-stage production protocol.
---
# mohen-carrier-reading

**身份：** DESIGN_TARGET_NOT_APPLIED；专业Owner=D01，逻辑层=L1，独立出口=G1。实际Executor在main源码存在；文件存在不证明方法、DB权限或Gate在线可用。
**唯一入口：** `pipelines/data-production/executors/d01-carrier-reading.mjs`。
**规范：** `specs/data-production/MoHen_Data_Production_Protocol.md` §11.3；`specs/AGENT_PROFESSIONAL_CAPABILITIES_CONTRACT.md` §3；资格由`specs/data-production/gates/G0-G5_MACHINE_GATE_CONTRACT_V3.0.md`唯一规定。旧阶段编号不再是可调用兼容入口。

## 触发与输入
G0有效来源修订、许可、载体与C01—C08路由。同一调用携带run/request、不可变type/id/revision、purpose/scope/consumer、source refs、依赖快照、权利和方法/工具版本；缺失则返回具名限制，不补造身份。

## 方法与执行
1. 检查项目授权、来源可用性、上游当前资格、执行预算和Registry激活。未授权不启动真实生产。
2. 读取本阶段规范并选择适用方法，不广播所有方法。技术读取与历史解释分开；OCR/VLM/ASR只产生识读候选；展示原件定位，模糊/缺页/不可读必须HOLD。
3. 仅持久化本阶段候选和回执，保存原文定位、限制与依赖；重试只限同快照的短暂基础设施失败。
4. 向独立G1提交候选请求；Producer/Skill/Adapter不写最终资格或自签审计。当前Reviewer未配置则返回gate_review_pending/HOLD。
5. 只有资格当前、用途和消费者匹配的eligible refs才交接下游；候选保存不等于资格PASS。

## 输出与写边界
可回放读取单元、页码/区域、原文、质量画像与识读不确定性；返回produced_refs、qualification_refs、eligible_handoff_refs、blocked_refs、control_events、disposition。只写L1的本职责候选，不跨层最终写入，不冒充独立G1签发者。物理schema由`specs/data-production/PERSISTENCE_BINDING_CONTRACT.md`定义，不按逻辑层名新造表。

## 失败、恢复与验收
原件不可得、定位/版本不明、版权限制、资格撤销、用途冲突、方法绑定缺失、预算超限均停止受影响分支；保留已保存合法候选和具体补证责任。恢复先重核依赖和权限，不能复用旧PASS。
正例：合法输入形成上述本阶段候选与独立资格请求；反例：上游失效、异用途、跨Owner或Producer自签均不得产生eligible refs。Stage结果不是独立G决定。真实低权限DB、Reviewer和运行测试由KAD4—5负责；本文件不激活它们。
