---
name: mohen-material-understanding
description: Use when carrying out MoHen D02 L2 production tasks under the six-stage production protocol.
---
# mohen-material-understanding

**身份：** DESIGN_TARGET_NOT_APPLIED；专业Owner=D02，逻辑层=L2，独立出口=G2。实际Executor在main源码存在；文件存在不证明方法、DB权限或Gate在线可用。
**唯一入口：** `pipelines/data-production/executors/d02-material-understanding.mjs`。
**规范：** `specs/data-production/MoHen_Data_Production_Protocol.md` §11.4；`specs/AGENT_PROFESSIONAL_CAPABILITIES_CONTRACT.md` §3；资格由`specs/data-production/gates/G0-G5_MACHINE_GATE_CONTRACT_V3.0.md`唯一规定。旧阶段编号不再是可调用兼容入口。

## 触发与输入
G1有效L1读取单元、H01—H25材料类型、上下文与来源谱系。同一调用携带run/request、不可变type/id/revision、purpose/scope/consumer、source refs、依赖快照、权利和方法/工具版本；缺失则返回具名限制，不补造身份。

## 方法与执行
1. 检查项目授权、来源可用性、上游当前资格、执行预算和Registry激活。未授权不启动真实生产。
2. 读取本阶段规范并选择适用方法，不广播所有方法。不能再次承担D01载体识读；区分作者年代、事件年代、叙述者、引文和模型解释；同源转引不算独立见证。
3. 仅持久化本阶段候选和回执，保存原文定位、限制与依赖；重试只限同快照的短暂基础设施失败。
4. 向独立G2提交候选请求；Producer/Skill/Adapter不写最终资格或自签审计。当前Reviewer未配置则返回gate_review_pending/HOLD。
5. 只有资格当前、用途和消费者匹配的eligible refs才交接下游；候选保存不等于资格PASS。

## 输出与写边界
材料观察、原文声音、语境、同源/转引、支持与反证；返回produced_refs、qualification_refs、eligible_handoff_refs、blocked_refs、control_events、disposition。只写L2的本职责候选，不跨层最终写入，不冒充独立G2签发者。物理schema由`specs/data-production/PERSISTENCE_BINDING_CONTRACT.md`定义，不按逻辑层名新造表。

## 失败、恢复与验收
原件不可得、定位/版本不明、版权限制、资格撤销、用途冲突、方法绑定缺失、预算超限均停止受影响分支；保留已保存合法候选和具体补证责任。恢复先重核依赖和权限，不能复用旧PASS。
正例：合法输入形成上述本阶段候选与独立资格请求；反例：上游失效、异用途、跨Owner或Producer自签均不得产生eligible refs。Stage结果不是独立G决定。真实低权限DB、Reviewer和运行测试由KAD4—5负责；本文件不激活它们。

## Visual Reading Boundary（承接 2026-10-05 视觉采集教训）
- 视觉载体读取必须建立在**已识别的实体身份**之上：只有当图像由权威身份（如 Wikidata `P18`、已确认 Commons 分类/页面）明确指认时，才可将图读作该实体的视觉证据；不得把同名命中的资产当作该实体（Commons 同名异地实测：日本石川县金泽市 vs 上海青浦金泽）。
- 只从**已确认资产**做 literal reading；以 `DateTimeOriginal` 判古今，现代照片不得读作历史状态证据。
- 许可未知的资产不进入 literal reading，先按 `mohen-visual-asset` 规则 HOLD。
