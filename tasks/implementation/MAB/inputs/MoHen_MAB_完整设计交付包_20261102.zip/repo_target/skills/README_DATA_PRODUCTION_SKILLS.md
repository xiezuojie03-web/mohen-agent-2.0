# Skill Active/Archive Manifest

> MHKA设计目标，尚未原子启用；不因文档归位激活Skill、Registry或生产。专业身份唯一Owner为`specs/AGENT_PROFESSIONAL_CAPABILITIES_CONTRACT.md` §3.2。

## 六个Stage Owner

| Skill | Stage | Layer | Gate | 唯一Executor |
|---|---|---|---|---|
| mohen-source-intake | D00 | L0 | G0 | pipelines/data-production/executors/d00-source-intake.mjs |
| mohen-carrier-reading | D01 | L1 | G1 | pipelines/data-production/executors/d01-carrier-reading.mjs |
| mohen-material-understanding | D02 | L2 | G2 | pipelines/data-production/executors/d02-material-understanding.mjs |
| mohen-world-construction | D03 | L3 | G3 | pipelines/data-production/executors/d03-world-construction.mjs |
| mohen-humanistic-discovery | D04 | L4 | G4 | pipelines/data-production/executors/d04-humanistic-discovery.mjs |
| mohen-read-model-publication | D05 | L5 | G5 | pipelines/data-production/executors/d05-read-model-publication.mjs |

## 七个共享活动能力

- `mohen-acceptance`：验收、证据与Human Review包装，不判断史学真值。
- `mohen-project-guard`：项目/上下文守卫，不替代DB权限或Gate。
- `mohen-vertical-slice`：纵向切片验证，不拥有跨层最终写权。
- `mohen-historical-spatial-source`：D00取得来源、D01读取载体、D02材料理解。
- `mohen-historical-spatial-reconstruction`：有证据边界的历史空间候选，Geometry is a Claim。
- `mohen-visual-asset`：D00图像获取、D01技术读取、D02材料理解、D03视觉对应。
- `mohen-experience-prototype`：MHKA-02体验；正式知识消费走L5，内部候选按项目授权隔离。

## 六个历史身份

- `mohen-association-discovery`：ARCHIVED，不创建新入口，不授执行权限；历史经验由现行专业合同承接。
- `mohen-data-ingest`：ARCHIVED，不创建新入口，不授执行权限；历史经验由现行专业合同承接。
- `mohen-evidence-gate`：ARCHIVED，不创建新入口，不授执行权限；历史经验由现行专业合同承接。
- `mohen-humanistic-selection`：ARCHIVED，不创建新入口，不授执行权限；历史经验由现行专业合同承接。
- `mohen-knowledge-weave`：ARCHIVED，不创建新入口，不授执行权限；历史经验由现行专业合同承接。
- `mohen-research-intake`：ARCHIVED，不创建新入口，不授执行权限；历史经验由现行专业合同承接。

## 绑定、失败与验收

19个身份=6 Stage Owner+7共享+6历史，不是19个活动Skill。63方法由method-binding-contract.json绑定；D00独立来源方法不计入C/H/W/A/P的63项。Loader只调用Registry明确的Executor，Skill正文不是动态加载已经实现的证明。正例：六个Stage恰好各一Owner；反例：旧D01来源入口、跨层写入、历史Skill复活或Skill自签G均阻断。回滚关闭新代际，保留审计与已撤资格，不复活旧缓存。
