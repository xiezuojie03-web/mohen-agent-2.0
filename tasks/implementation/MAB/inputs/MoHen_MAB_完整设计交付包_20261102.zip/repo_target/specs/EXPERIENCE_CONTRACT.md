# MoHen Experience Contract｜MHKA代际目标候选

> `status: DESIGN_CANDIDATE_NOT_APPLIED` · `generation: mhka.v1` · `file_owner: MHKA-05`
> 体验语义由MHKA-02和U07 V4定义；知识资格由MHKA-03定义；导演/Agent能力由MHKA-04定义。本合同只承接运行状态、交互和合法消费，不自定义第五页之外的产品模式。

## 1. 正式逻辑代际

**L5 = 可信发布的六类派生知识分面；L6 = Experience Runtime；L7 = 参与；L8 = 文化新痕迹。** 原Experience Contract所称 `L5 Experience Runtime` 只属于旧代际，须完全隔离。L6从合法L5及依法允许的项目级研究候选编排体验，不拥有历史Truth，也不能自作G签发。

## 2. 五图与三类内容模式

- `F01 HOME`：价值引导、公开目录、授权入口、用户身份可见分区和导航，不泄露未发布草稿。
- `F02 Studio`：宽屏三工作面（左自然语言、中央Agent研究/导演进度、右实时作品），窄屏按工作区切换；内部研究、导演、预览、定向修改、作品版本、投稿、失败恢复和项目权限持续一致。内部研究读取须标注候选身份，不能由作品预览自动获得G5。
- `F03 WATCH`：消费合法公开的作品版本、节目时序、证据按需和跨场景导航；撤权后不继续播放无权分面。
- `F04 EXP`：围绕当前允许消费的知识资产独立探索，依赖真实时间、空间、关系和Evidence on Demand；视觉舞台与墨痕叙事为体验内核，证据面板按需出现，不能把冻结示例误当已开放世界。
- `F05 Admin`：有权查看审核、发布、资产、成本、失效和资格申请；运营审批不能代替史学Gate。这里不是公众第四个内容模式。

## 3. ExperienceState / Action / Patch

状态至少区分当前会话/身份/项目、适用产品模式、目标与用户意图、历史知识引用版本、舞台图层/镜头、叙事节拍、展开/隐藏偏好、待决研究/工具调用、错误/失效信息、返回锚点。具体字段由后续机器Schema和已有 `packages/experience-engine/` 对照冻结，**不得凭本描述杜撰已存在字段**。

`ExperienceAction` 是已授权产品行为，不等于Skill、Tool或Gate签发。对一个局部节拍/视图做 `Patch-not-Replace` 时，必须保留无关作品/舞台状态、会话与用户可见偏好；只有与新目标直接冲突的状态有依据地变更，保存回执和可恢复版本。长任务过程不得让UI显示假的“完成”。

## 4. 合法消费与资源失效

公开WATCH/EXP遵守当前有效作品、知识发布分面与对应消费者用途/权利；Studio的合法项目研究资料只能在受控工作区显示且带限制，不能直接流入公开舞台或被公开缓存继承。原件图片、复制图、AI复原、现代位置与历史几何各有身份与证据等级。

撤权或时效到期先阻断不合法分面；合法未受影响片段仍可保留，并显示缺失/补证提示。跨模式从WATCH→EXP或EXP→WATCH返回须保存原始锚点及版本，避免将两个会话的权限混同。

## 5. 可验证的体验质量

保留H1/H2/H3方法与两核心组件的适用模式，不强制三栏Studio或Admin复用EXP布局。U07 V4的五图62模块、152动作与候选API/组件是**验收输入**，不是已经运行通过的报告。桌面/平板/手机应验证：首次对话推进实际研究、版本可复现、局部改稿、审核发布一致性、原件/依据可达、地理空间表达有界、费用/证据失败清楚、授权和撤权稳定。

## 6. 工程继承及真实状态

已有 `packages/experience-engine/src/experience-runtime.ts`、Studio/WATCH/EXP/Admin API和 `apps/web` 前端，不应另造第二套体验事实源。新旧合同切换前逐项验证其当前字段、调用者、测试、发布/权限缓存及运行状态；旧 `L5 Experience Runtime` 对应当前L6的兼容映射必须显式写入测试，而不是批量替换所有字符串。

**激活规则：** 仅作为K3目标设计；无Owner工程恢复授权及真实回归，不修改当前GitHub合同或宣称用户体验已验收。


## 7｜H/I与机器体验的唯一职责分割（KAD1-C镜像必需）

- 叙事母题、H1共45检查、H2七导演判断、H3节拍验证、19个I组件的完整专业合同：`specs/experience-ui/H1_H2_H3_AND_COMPONENTS_CONTRACT.md`。
- 本文件独占ExperienceState/Action/Patch、受控消费者输入、可见失败与前端运行边界。
- `specs/requirements/u07-action-contracts.csv`保留152项设计动作，不将19组件误当功能上限；五图用户视觉目标和UXD-01暂停状态均保留。


## KAD1-E｜视觉舞台真实读模型的失败关闭

`apps/web/lib/read-model-bridge.ts`仅消费对应用途/范围/consumer当前有效的独立G5分面。数据库失败、资格不存在、权限/权利不明时只报告明确的不可用或受阻状态；不得自动退回冻结JSON作为真实发布。主题定位须绑定参数并转义LIKE通配符，不跨课题混读；照片缺少明确授权时不得以“license待核”占位值呈现为已获授权展示。专用演示fixture必须标注模拟，永不共享公开真实资格或缓存。

## 8｜KAD3—KAD5知识业务投影与五图消费的状态合同（KAD6）

- F02 Studio原三工作面需要表现`actual root_task/subtasks/delegations/receipts/asset_revision/D-G/rights/cost`与真实作品/导演修订；`QUEUED`不能冒充已研究，保存工作资产不等于知识G和公开发布。局部改稿保留其他合法节拍/镜头，真实rev/CAS失败应能恢复。
- F05 Admin仍为运营审核、发布、权限、研究方向与知识条目等共同组成的**一个**运营平台。知识资产只是一个内部功能域，授权`AdminAuthorizedItemViewV1`从L/Studio/作品主数据派生`catalog_ref,origin_kind,asset@rev,epistemic,status,source/raw/locator,rights,current_G,use_history,knowledge_delta,gaps`；**不新建独立知识平台**。此前KAD3独立HTML未经Owner认可，不作为本代施工图。
- F03 WATCH基于同一`WorkRevision@rev`和publish pointer获得当前权利允许的内容；消费时再次检查Operator+当前G5/consumer/purpose/action/版本/依赖与媒体权利。不凭单纯published字符串/静态JSON/旧缓存展示已撤权原件。受影响片段可定向阻断；不可分割的关键事实失效应阻断该章节或作品。
- F04 EXP在设计包中保留H/I、L6—L8和Evidence on Demand的合同，工程启动顺序可延后但不能从完整设计中删除；不要求本阶段重新做全套UXD视觉风格。`experience.runtime_sessions/events`属于运行态，普通观看点击不直接成为L7贡献或L8历史事实。
- 正反验收`EXP-K6-P1`Studio可从真实合法来源持续研究并恢复修订；`N1`无真实Agent回执仍显示完成；`N2`Admin作为独立平台；`N3`WATCH旧稿资格过期或媒体权利撤销继续公开；`N4`旧观看会话越过Owner ACL；以上均设计责任，工程真实验收另签。
