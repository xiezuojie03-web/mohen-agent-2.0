# 六阶段工程衔接总合同

> DESIGN_TARGET_NOT_APPLIED｜2026-10-15。专业与工程衔接文件准备，非开工指令。基线handoff/local-b-20260930@8966d1b；已获准编制交付ZIP，尚未应用真实代码/PG/Schema/Git/Production；56正式延期DESIGN_HOLD，真实G5及MIG-01 HOLD。

## 1｜文档与实现分责

standards/宪法/Protocol/DATA/PERSISTENCE/Gate与机器配置是ChatGPT已编制的目标专业文件。真实代码/SQL由获授权的工程工具在用户授权、M0核实后按tasks/implementation/ARCH-MIG-01逐文件实施。未实现的.mjs/.ts不放空壳冒成完整目标源码；每个受影响源码必须在TARGET_FILE_COVERAGE.csv有明确动作、合同与场景，且没有未分派缺口。

## 2｜稳定接口封套

Method输入run/request/context、typed refs、carrier/material profile、method/source version、purpose/scope/consumer、current qualifications与snapshot；输出typed drafts/limitations/control requests。Stage保存候选与生产过程，不自授资格。独立Gate请求/返回遵DATA_CONTRACT与qualification schema。Hand-off仅显式eligible refs；消费上下文不可省略。物理表/服务接口按M0核定，现存export改动所有调用方需测试，不能用猜测签名冒现状。

## 3｜新增与退役

新增D00-source-intake与D01-carrier-reading执行入口，旧d01-source-intake退出新代际；不机械复制两份旧mixed executor。新method/gate配置禁用，激活需要完整语义验证、真实独立绑定及用户授权后的运行配置版本。新配置不能直接喂给仍固定5 job的旧loader。

## 4｜文件与场景齐备

TARGET_FILE_COVERAGE逐目标文件；PINNED_REPOSITORY_DISPOSITION全仓库树归类；REAL_PATH_FINDINGS记录实际代码证据；scenario-contracts逐场景预期。齐备=专业目标文件真实存在且格式/引用一致，受影响源码都有具体实施合同和测试归属，真实工程未知明确M0。齐备不等于源码已改或运行已测；ZIP已由用户明确授权，工程仍须分批发令。

## 5｜MHKA本代精确交接

此前获授权的工程工具、五Job和待建D00描述保留为历史设计来源；main@db21cefcc09c6bcb5d7e3fca16d100cc0accd13d已有六Executor、执行授权和独立Gate仓储，禁止重新创建覆盖。实际实施工具可为获授权的Codex，不固定供应商。
专业规则由`specs/data-production/MoHen_Data_Production_Protocol.md` §11、`specs/data-production/gates/G0-G5_MACHINE_GATE_CONTRACT_V3.0.md`、`specs/AGENT_PROFESSIONAL_CAPABILITIES_CONTRACT.md`、`specs/experience-ui/H1_H2_H3_AND_COMPONENTS_CONTRACT.md`、`specs/KNOWLEDGE_ASSET_LIFECYCLE_CONTRACT.md`自足承接，旧研究不是运行隐藏输入。唯一正式镜像按仓库根相对路径归位；无差异KEEP、待实现代码、实际运行状态和历史候选不混入可覆盖文件。
工程实施逐条读取00总览的现行路径索引、文件哈希和原Blob：基线变化三方比较；同路径使用新规范目标，保留新main有效修复。源码、API、动作、DDL、角色、测试各列消费本合同的责任。实现阶段需生成精确源码Diff与低权限正反证据；本轮不拿旧K3源码草案冒充最新目标。
验收顺序：路径/唯一Owner→正文/机器形状→调用与正反责任→隔离测试→授权激活→线上/Owner。前项通过不代后项。停止时保留资产和审计；恢复关闭新路由但不复活撤权缓存。

## 6｜KAD1最终设计目标的受控应用顺序

1. 固定最新main，若非本次基线先三方比较；逐文件检查原Blob与目标SHA，保留所有KEEP原文件。
2. 在无生产凭据环境核Schema、类型、当前测试和新增21个隔离用例；真实DB用已有隔离夹具验证新增3组SQL、当前角色、签名会话和RLS。
3. 经独立工程授权备份数据/权限、应用具名迁移及签名密钥与MOHEN_G5_CONTEXTS配置；缺策略映射或密钥时HOLD，不提供默认放行。
4. 同步部署历史修订读取、私有附件显式HOLD、消费/发布/角色/观看隔离代码；只有显式运营POST可触发到期发布。
5. 新旧MHKA路由按AGENTS/OWNERSHIP原子切换；真实结果写CURRENT，不把本轮设计报告作部署证明。
6. 任一失败关闭新路由/写入/消费，使用对应非破坏rollback；保留用户进度、消费阻断和已签审计，禁止回滚到跨用户共享或恢复已撤资格。

本次KAD1终审仅准出规则、差异、完整目标正文与可执行验证责任。KAD2—5各自的功能深化和真实投运仍执行原任务书，不被本阶段提前声明完成。


## KAD1-E新代际工程工具中立交接

迁移前必须核最新`main`/HEAD、实际运行、数据库角色及已施工差异；历史K3/UXD7包仅为来源和差分凭证。工程工具不得依靠旧CodeBuddy专用语句决定合同权威；以`AGENTS.md`路由的MHKA和经证据签署的现行`repo_target`增量清单为唯一执行目标，任何真实写入需另行授权、测试、备份和回滚。
