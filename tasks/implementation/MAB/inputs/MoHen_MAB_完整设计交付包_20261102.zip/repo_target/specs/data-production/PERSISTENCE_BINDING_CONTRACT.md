# Persistence Binding Contract V2.0｜K3定向修订目标

> `DESIGN_TARGET_NOT_APPLIED`。此文件是对原 `specs/data-production/PERSISTENCE_BINDING_CONTRACT.md`（GitHub blob `5388e354fddbf31c87cfbc291835248260a1faf7`）的原路径修订候选，不是已运行数据库或另设数据库体系。专业资格语义仍由既有 G0—G5 规范和 `qualification.schema.json` 唯一定义。技术修订须保持六阶段生产、来源、D01读取、历史数据和现有调用方。

## 1｜唯一写入责任和分权

| 主体 | 允许 | 禁止 |
|---|---|---|
| D00—D05生产者/Adapter | 各自 L0—L5 候选、版本、Stage检查和签发申请、生产过程状态 | 直接签发G0—G5资格PASS；更新当前有效资格；覆盖历史裁决 |
| 独立G0—G5 Reviewer服务 | 审核精确对象修订、用途、范围、消费者、依赖及证据，并在独立DB身份下追加裁决 | 为生产者冒名签发；更改生产候选、绕过审核 |
| 治理晋级服务 | 治理事件和作品流转控制数据 | 调用 `writeGovernanceGate()` 自动插入专业G5 PASS |
| Operator作品运营审核 | 作品运营决策 | 授予史学G0—G5资格 |
| 作品Publication Reviewer | 作品引用、媒体、版本审核 | 以作品签核代替独立知识资格 |
| Runtime / WATCH / EXP / Studio | 按受控消费者、项目和用途合法读取；L6运行态 | 通用读取历史PASS充当对外资格；写入L0—L5 Truth |
| P08 / Guard | 记录失效事件、阻断读、申请独立重审 | 自动伪造REVOKED或新PASS |

同一自然人可兼任角色，但一次调用只使用被授权的**单一执行身份**，并独立记录审计；生产者DB凭据绝不应拥有直接写有效资格的权限。Service-role、函数属主和绕过RLS的路径同样需要约束与负测。

## 2｜以真实已存在数据库为基础

已静态核查 GitHub `supabase/migrations/202610160300_six_stage_gate_audits.sql` (`2e5aa5bb3ee383f4878a9f5cbd8d6cb922b2b205`)：`control.gate_audits`在迁移中已添加 `architecture_generation`, `purpose text`, `allowed_scope jsonb`, `consumer text`, `dependency_snapshot jsonb`, `effective_time timestamptz`, `input_fingerprint`, `output_fingerprint`, `rule_version`, `supersedes_id`, `current_valid`；六阶段门检查及 `source.read_runs/read_units/read_quality_checks/read_handoffs`和 `evidence.read_unit_evidence_links`已有DDL。**保留这些实体，禁止因目标模型而重造第二组 L1 表。**上述SQL中`DROP VIEW ... CASCADE`为历史迁移事实，绝不可未经检查用于生产重放。

`qualification.schema.json`的逻辑字段与当前物理记录尚非逐列等价：

| 逻辑资格字段 | 现有可对应数据 | 必要差额/目标处理 |
|---|---|---|
| decision_ref | gate_audits.gate_audit_id | 可复用标识，但写入责任必须独立 |
| gate | gate_code | 保留六门枚举与stage一致性 |
| artifact_ref.type/id/revision | object_type/object_id；未见revision专列 | 先复用对象标识；修订须确定真实来源/索引后有界扩展，不能猜测 |
| purpose.namespace/code/version | purpose text | 明确版本化无损映射；旧文本未知->HOLD，不自动PASS |
| allowed_scope / consumer | allowed_scope jsonb / consumer | 明确非空与规则验证，不能仅可选匹配 |
| dependency_snapshot | dependency_snapshot jsonb | 与原资格 schema 的数组、依赖版本快照转换和一致性校验，未知->HOLD |
| effective_at/valid_from/valid_until | effective_time / 既有checked_at | 有效区间与过期字段不足，先查全量DDL及消费者后补列；不得编造无限期 |
| reviewer.id/role | 未证在迁移中独立存储 | 独立签发者身份+角色+规则版本必须存证并验真 |
| previous_decision_ref | supersedes_id | 可复用链，但历史记录不得变更签发内容 |
| decision + evidence_refs | result、details/guard_versions等 | 证据引用须结构化且可追溯，历史裸PASS不得自动继承 |

**当前Gate表是既有物理资产，不等于最终合法资格表。** `current_valid`目前由生产者 UPDATE，必须改变其权限语义；可保留作为可重建投影字段或在未来基于现有表做最小拆分，但必须先完成完整DDL、调用方、锁、事务及兼容/回滚审核。**不得现在指定未经查证的新表名、索引或部署SQL。**

## 3｜现有代码最小改动范围

- 保留 `pipelines/data-production/run.mjs`、六个 Executor、`orchestrator/contracts.mjs`与D00—D05传递语义。
- `pipelines/data-production/adapters/layer1-adapters.mjs/writeGate()`：原地调整为生产Stage检查/资格候选提交；去除对有效资格的直接UPDATE/INSERT PASS能力，保留有证据的候选提交与异常恢复。
- `packages/data-access/src/data-production-repository.mjs/recordGate()`：保留现有Repository接口作为兼容包装，但不得以普通producer身份直接更新资格。`passed()/legalInput()`目前仅查询 `gate_code/result='PASS'/current_valid`，未来必须调用独立资格验证器，匹配purpose、consumer、对象修订、依赖、时效、权利、签发来源；签发不明->BLOCKED。
- `apps/web/lib/governance-gate.ts/writeGovernanceGate()`：保存治理晋级控制事件，但不能写史学G5 PASS；作品审核仍复用既有Reviewer服务。
- `packages/data-access/src/read-model-repository.mjs`：保留六类L5映射与已有消费者隔离；公网读取不允许缺consumer进入审计宽读取；补全部资格断言，合法分面可单独撤权。
- `control.production_runs`及运行回执要一致记录；终态落库失败不能静默形成完整审计PASS。

## 4｜独立签发事务及不可变历史

签发输入至少为 `actor_id/role, artifact_ref{type,id,revision}, gate, purpose{namespace,code,version}, allowed_scope, consumer, dependency_snapshot, rule_version, evidence_refs, effective_time, decision, previous_decision_ref, request_id`。先复核资格前提与调用者授权，事务内锁定同一资格键，对当前有效指针作并发检查、追加新裁决，再更新可重建当前投影；失败回滚，不留下半签发状态。历史裁决不得UPDATE/DELETE；为兼容而改投影不等于修改历史决策。独立G签发服务的数据库角色和证据结构仍需逐列审计后再转为DDL。

## 5｜必须有的未来工程验收与失败门

1. Producer、Studio、Operator和普通Service角色调用直接G-PASS写入：DB级拒绝；独立Reviewer受控调用：通过。
2. 两个并发签发同一资格键：只有一个有效当前投影；历史裁决完整且可重放。
3. 缺对象revision、purpose版本、证据、dependency/consumer、签发者：拒绝或HOLD；不得默认填充旧PASS。
4. G3合法事实投影不必伪造G4；解释内容需要G4；公开L5必须有当前、匹配消费者和用途的G5资格。
5. 撤权后缓存/公共读取立即拒绝，但不推断撤销无关合法分面。
6. 旧API、旧消费者、旧数据记录及导入流程必须有迁移前后兼容对照和可逆恢复验证；禁止未授权执行迁移。
7. 生产数据数量、运行中的PG列/权限、RLS、函数属主与服务账号尚未核实：`DB_RUNTIME_VERIFY / SEC-01_HOLD`。

**K3判定：机器持久化设计已具体化，但仍未冻结可运行DDL及真实角色授权。工程未授权，不能宣称独立G已运行。**


## Registry 与独立资格运行衔接：下一工程验收准则

# K3 Registry Loader 与六阶段运行授权定向合同（目标施工输入）

状态：`DESIGN_TARGET_NOT_APPLIED / K3_REVIEW_REQUIRED`。本文件是拟并入既有 `specs/data-production/MoHen_Data_Production_Protocol.md` 相应章节的**有界增补正文**，而非新建并行有效规则文件；在源文件得到完整定向改稿前，仅存放于 K3 `00_总览` 的执行差异记录，不放 `repo_target`。源码依据：`xiezuojie03-web/mohen-agent-2.0@759dbbd0c206c4acfe2ebdc3e94aa556528b330c`。

## 继承不可变项
- 保留 `pipelines/data-production/orchestrator/registry.mjs` 的六个 Job 对齐、唯一 Stage Owner、`jobForStage` 查找；保留 `load-executor.mjs` 的六个执行器、`orchestrator.mjs` 的 `STAGE_CONTRACTS[stage].output` 显式交接以及部分恢复输入检查。
- 保留现有 `production-registry.json` 单一数据源和 `schemas/production-registry.schema.json` 单一机器 Schema，禁止再建注册表、运行管线或 Skill 层。

## 目标前置判断顺序（拒绝优先）
1. `loadRegistry`: 校验 JSON 可解析且 Draft 2020-12 Schema 通过；检查精确 `schema_version=4.0-target`、`architecture_generation=mohen.six-stage.v1`、D00—D05 各一次及 Dn/Ln/Gn 紧耦合。任何失败抛带稳定 reason_code 的错误。
2. 区分**设计态读取**与**执行态启动**：设计态可以读取 `DESIGN_TARGET_NOT_APPLIED` 的 Registry 供审查，但不得由此推断可执行。无有效的工程准入签发，不能从命令行 `run.mjs`、API、Studio Agent 或其他调用点执行阶段。
3. 启动 `runProduction` 前：强制检查所选全部 Job 的 `execution_policy.enabled`、对应执行模式 `attended/unattended/batch/interactive`、运行请求主体上下文/Scope/预算、全局 activation 与法律/资格 HOLD；**任何一项为 false/未校验即拒绝**。切勿将 `activation.enabled=true` 看作自动获准执行。
4. `runProduction` 在每次调度阶段前复查有效授权/撤权/输入快照；检查通过后才 `loadExecutor`，防止绕过 CLI 直接导入编排器。当前 Registry 六 Job 全禁用且 Reviewer 为 `TO_VERIFY_IN_M0`，故此目标规则下所有正式执行均应拒绝。
5. Stage 结果 `PASS` 是方法/运行处置，不能用作 G0—G5 独立资格 PASS；Stage 之间需合法上游资格。生产者可提交候选与证据；合格与否只由独立审查方/资格接口裁定。
6. `run.mjs` 中进度与终态持久化失败时，保留业务运行结果证据，同时报告 `runtime_record_consistency=FAIL` 和可恢复状态，**不得以完整审计 PASS 的形式退出或发布**。

## 实施修改精确边界
- `orchestrator/registry.mjs`: 原文件增加机器 Schema 验证及版本/代际/状态解释；不要重新开发 Stage Owner 校验。
- `orchestrator/orchestrator.mjs`: 在实际调用 `loadExecutor` 前加入不可绕过的运行授权 Guard，不改结果输出键选择。
- `run.mjs`: 在原 CLI 增加运行授权预检与失败状态结构，不复制第二个 CLI。
- 资格授权 Guard 需复用原 `gate-contracts.v3.json`、资格查询与独立签发服务；若服务未就绪，则 fail-closed，不能在本合同凭空指定为已存在。

## 最低静态和未来工程验收
- 正例：六个唯一 D/L/G、明确未激活的 Registry 可以被设计工具解析；经独立授权的隔离测试 Job 才可执行，结果按原 `STAGE_CONTRACTS` 交接。
- 负例：旧 V3 Schema、重复 D03、D01→G2、缺 G Reviewer、`TO_VERIFY_IN_M0`、disabled Job、未获批准 mode、未登录调用、来自 Studio 的直接编排绕过、撤权后继续、`onStage`/终态 DB 拒绝。
- 断言：每种拒绝均没有调用任何 Adapter，不写新的正式 Gate PASS；日志和退出码能够区分 `BUSINESS_HOLD`、`AUTH_DENIED`、`PERSISTENCE_INCONSISTENT`。

注意：上述是**目标设计**，没有运行实际代码、数据库或端到端验收。正式工程修改仍须 Owner 独立授权。

## K3｜真实迁移与Repository列级一致性专项（2026-10-31；实施未授权）

本节绑定 GitHub 固定提交 `759dbbd0c206c4acfe2ebdc3e94aa556528b330c` 的 `supabase/migrations/202610160300_six_stage_gate_audits.sql`（blob `2e5aa5bb3ee383f4878a9f5cbd8d6cb922b2b205`）、`packages/data-access/src/data-production-repository.mjs`（`352bdff7733760ee37767919362b26e0e5db5761`）。这只证明迁移脚本和源码文字，不证明真实PG已经应用。

### 已确认的现有列（不能重复建表）

`control.gate_audits`：原有 `gate_audit_id`、`run_id`、`stage`、`gate_code`、`object_type`、`object_id`、`result`、`reason_codes`、`details`，迁移补 `architecture_generation text NOT NULL DEFAULT 'mohen.six-stage.v1'`、`purpose text`、`allowed_scope jsonb DEFAULT '{}'`、`consumer text`、`dependency_snapshot jsonb DEFAULT '{}'`、`effective_time timestamptz`、`input_fingerprint text`、`output_fingerprint text`、`rule_version text`、`supersedes_id uuid REFERENCES control.gate_audits(gate_audit_id)`、`current_valid boolean NOT NULL DEFAULT true`。此清单中的原有列数据类型和全部约束，尚需读取建表原始迁移和线上 `pg_catalog` 才可冻结，不得推断。

`source.read_runs`、`source.read_units`、`source.read_quality_checks`、`source.read_handoffs`、`evidence.read_unit_evidence_links` 由已有迁移创建或定义，保留既有L1路线，不做另一组读取表。

### 与资格目标 Schema 的逐字段缺口

| 独立资格目标字段 | 现有表映射现状 | 必须处理的设计合同 |
|---|---|---|
| decision_ref | `gate_audit_id` 可作为身份候选 | 明确UUID文本序列化与业务引用稳定性，不接受历史PASS直接升格 |
| artifact_ref.type/id/revision | `object_type/object_id` 仅覆盖类型与ID，修订字段缺口 | 补全不可变修订或独立关联列/表；不得覆盖原ID |
| purpose.namespace/code/version | 现有 `purpose text` 无法无损表示三个字段 | 定义规范化JSON结构或独立版本化关系，旧字符串只保留历史解释而不自动赋予资格 |
| allowed_scope | `allowed_scope jsonb` | 匹配对象/操作权限与有效范围；空对象不得被解释为无限授权 |
| consumer | `consumer text` | 非空及授权枚举/注册来源；分消费者投影不互相撤销 |
| dependency_snapshot | `dependency_snapshot jsonb` 默认对象，目标为数组 | 定义逐引用列表及版本比较与历史转换规则；禁止默认空对象放行 |
| decision | `result`（五态） | D运行结果与G裁决物理分权，生产者不可直写正式裁决 |
| rule_version | `rule_version text` | 签发前必须锁定规则来源版本 |
| reviewer.id/role | 未证对应独立身份列 | 独立角色及审计不可由应用层自报，无证据不得签PASS |
| effective_at、valid_from、valid_until | `effective_time` 仅覆盖候选时点 | 不能凭历史记录推断有效区间；新PASS按目标schema强制时间有效性 |
| previous_decision_ref | `supersedes_id` 候选 | 追加独立裁决链而非覆盖旧行；并发须保持唯一当前投影 |
| evidence_refs | `details jsonb` 仅可能包含证据 | 未证明结构与权利前不可无损升级；签PASS必须有实际证据引用 |

### 最小数据库分权的可执行前置检查

工程阶段先在隔离的 schema 副本上由授权数据库工程角色读取 `pg_class/pg_attribute/pg_constraint/pg_policies/pg_roles/pg_default_acl`、`information_schema.role_table_grants`、触发器及 SECURITY DEFINER 函数；核对真实依赖和旧迁移是否已执行。生产者连接角色必须无法 `INSERT/UPDATE/DELETE control.gate_audits` 的正式裁决记录；独立审查服务以专属角色通过原子事务追加审计、刷新当前投影，并确认身份不可伪造。**不能只对HTTP做403而不收紧DB角色**。服务密钥若共用超级权限，需先拆角色/入口与调用者，不能把RLS声明当隔离已经生效。

未证明 DDL、既有 RLS、GRANT、在线版本或回填来源前不生成可执行的 `ALTER TABLE/REVOKE` 迁移 SQL；不得复制清空/重建任何表。对并发双签、伪造Reviewer、跨用户操作、空用途、到期、依赖变更、旧PASS继承、事务中断和撤权重算分别规定负例。当前结论 `TARGET_DESIGN_WITH_PHYSICAL_SCHEMA_HOLD`，非运行资格解禁。

## K3真实守卫冲突｜原路径最小修订责任（默认分支再次核实）

除数据库层独立签发外，仓库已有若干守卫，应优先定向修订，不再创建新一组测试引擎。

- `scripts/check-production-registry.mjs` (`01ff21bbefbdf73bbae7fa201139f4a7514104f2`)仍要求旧`schema_version`数字、旧`required_fields`、`production_mode/truth_write_ceiling`等字段；六阶段Registry是字符串`4.0-target`且Job结构不同。根`package.json`的`guard:registry`仍指向该旧守卫；六阶段新守卫已在`scripts/guards/check-production-registry.mjs` (`bc66dd94c48a5f8740fbbf70f6b1d918a98a90aa`)存在。**只需定向将默认guard:registry入口指向现有六阶段守卫**（完整原路径`repo_target/package.json`候选），历史旧守卫保留历史身份。不重写Registry架构，额外补齐完整Schema验证及运行授权测试。
- `scripts/guards/check-gate-enforcement.mjs` (`ad184a619b8e52178220692ecd5e162d4d54652f`)已有G1—G5上游合法性模拟测试，**必须继承**。但“无on conflict、含current_valid”不能证明独立签发，现有`recordGate()`依然UPDATE/INSERT正式资格；应原位增加Producer直接调用recordGate和治理写G5的拒绝测试、Reviewer身份/角色/DB负测、用途/版本/有效期/依赖检验。
- `pipelines/data-production/adapters/persistence-contract.mjs` (`1e995392d65bf94855923c241026e78e8bffdfed`)原`ALLOWED_SCHEMAS`给D00—D05全部包含`control` schema，仅按schema白名单验收。这允许生产运行记账但**不能区分`control.production_runs`与`control.gate_audits`**。保留进度记录合法入口，在已有函数中新增表/操作级受控白名单；原Guard `scripts/guards/check-cross-layer-write-boundary.mjs` (`21729fb068a9c56f0650a7a4ff2b9bd5f8a41dab`)同步补正负测。DB角色最终强制拒绝仍不可省略。
- `scripts/check-auth-coverage.mjs` 通过检索route的字符串判断鉴权覆盖，仅能作为静态线索；对公共evidence、内部Studio跨资源plan、公开读模型的资格/行级负测必须另设细粒度场景，不能因为`guard:auth:strict`通过就认定安全。

上述属于**必要定向变更**而非新的守卫平台；原项目单元测试继续继承。任何切换后应在隔离分支验证`pnpm guard`/`pnpm guard:registry:v3`、六阶段Job关闭的真实拒绝、旧五阶段可归档但不并行active，工程未执行前保留`NOT_RUN`。


## K3-C1｜2026-10-31 物理映射、最小DDL差分与转移合同（源迁移直接复核）

**证据固定到 `759dbbd0c206c4acfe2ebdc3e94aa556528b330c`，设计候选不允许执行。** 此节只增加既有本文件细节，不创建新的数据库规范。已直接读取：

- `supabase/migrations/202610070100_data_production_v2_baseline.sql` blob `49d3b9d5c91f6d06212814c1a8b8fc46e495cd00`：定义 `control.production_runs`、`control.gate_audits` 基表及其原主键、运行FK、三态Gate枚举、唯一 `(run_id,gate_code,object_type,object_id)`；旧视图以 `result='PASS'` 查询，不足以证明当下合法。
- `supabase/migrations/202610160300_six_stage_gate_audits.sql` blob `2e5aa5bb3ee383f4878a9f5cbd8d6cb922b2b205`：已删除上述旧唯一键、增加六阶段、五态枚举、purpose/consumer/依赖/时间及 `current_valid`；**历史脚本含 `DROP VIEW ... CASCADE`，仅作来源，不允许复放**。
- `packages/data-access/src/data-production-repository.mjs` blob `352bdff7733760ee37767919362b26e0e5db5761`：`recordGate` 先 `UPDATE current_valid=false`，再直接 `INSERT PASS`，`passed/legalInput` 只以PASS/current_valid选择；必须同时定向修订。
- `specs/data-production/schemas/qualification.schema.json` blob `4597bfa58cf18f921a7acbd55ca68112cf7508ee`：PASS强制 `valid_from, evidence_refs` 及 `valid_until` 或 `long_term_basis`；`artifact_ref.revision`、`purpose.namespace/code/version`、`reviewer.id/role`和数组式`dependency_snapshot`为规范目标。
- `supabase/migrations/202610292100_imported_materials.sql` blob `b824ee5e44441ba710560e7e7e6491fec479c81f`：表 `public.imported_materials` 已有 `owner_user_id uuid references public.users(user_id)` 及索引；脚本没有RLS政策。真实用户会话ID与 `public.users.user_id` 的映射须在后续工程证明。

### C1-A｜资格存储的**具体目标字段**（必要DDL差分，不是已部署SQL）

采用**现有 `control.gate_audits` 为唯一历史Gate决定载体**，禁止另造同一含义的Gate历史表。旧行保留；以有界`ADD COLUMN`补充以下已知缺项：

| 唯一业务字段与物理目标 | 现有已证字段 | 候选迁移/验证规则 |
|---|---|---|
| `artifact_revision text` | `object_type`、`object_id uuid` | 新合格裁决必须非空；从对应产物版本或稳定哈希读取，旧行未知则保留legacy，禁止猜造revision。 |
| `purpose_namespace text`、`purpose_code text`、`purpose_version text` | `purpose text` | 新资格必须全部非空并与purpose结构对象一致；旧text不经版本化来源确认不自动转换。 |
| `reviewer_id text`、`reviewer_role text`、`reviewer_proof_ref text` | 当前无独立签发身份列的证据 | 身份须来自服务器验证后的独立签发上下文，不能信任JSON body自报。 |
| `valid_from timestamptz`、`valid_until timestamptz`、`long_term_basis jsonb` | `effective_time`、`checked_at` | PASS须满足开始时间及期限/长期复审理由的互斥或适用策略；时间按UTC，不能默认为永久。 |
| `evidence_refs jsonb` | `details jsonb` | PASS至少一条合法证据引用，旧details不明则标为legacy待审。 |
| `dependency_snapshot jsonb` | `dependency_snapshot jsonb default '{}'` | 目标Schema要求数组；迁移采用受控 `jsonb_typeof='array'` 的规范化检查，旧对象绝不悄悄转空数组。 |
| `allowed_scope jsonb`、`consumer text`、`rule_version text`、`supersedes_id uuid` | 现有列保留 | 新资格必须明确受众、许可范围、规则版与前次决定链接；空默认值不能成为PASS。 |
| `decision_ref` | 既有`gate_audit_id uuid` | 将uuid外部字符串化即可；保留原PK和FK，禁止为符合Schema再建立等价ID。 |

**重要设计取舍：** 不在 `gate_audits` 上继续UPDATE旧行 `current_valid` 来表达新资格。必须将既有可变`current_valid`标记确定为**遗留兼容字段**，新合格决定的完整事实只追加且禁止UPDATE/DELETE；另设**最小当前状态投影**（推荐 `control.qualification_current`，仅用于精确键指向最新`gate_audit_id`与投影版本、撤权状态和更新时间）。这是有界新增的一个索引/投影实体，非第二套知识资格定义；仅在检查现有等价投影确实不存在后准许CREATE_IF_GAP。若现有表/视图足以原子实现等价投影，则优先原位改造而不是新建。设计须保证历史 `control.gate_audits` 与投影的依赖/外键和回退同时有效。

`qualification_current` 业务唯一键固定为：`(gate_code,object_type,object_id,artifact_revision,purpose_namespace,purpose_code,purpose_version,scope_digest,consumer,dependency_digest)`。其中两个digest以**规范化JSON**计算，算法、排序、哈希版本和跨语言一致性必须固定后上线，禁止依赖未规范化JSON的序列化次序。值列至少有 `current_gate_audit_id uuid`、`projection_version bigint`、`current_status`、`updated_at timestamptz`。当资格过期、撤权或依赖变化时，不能只信静态投影；对外读取须核真实规则与依赖，再决定ALLOW/DENY/HOLD。

### C1-B｜事务、接口与DB授权的最小一致执行序列

1. 原Stage执行器保留；`recordGate`、Adapter `writeGate`、治理 `writeGovernanceGate` 停止具备**正式Gate决定表**的写权限。生产者向原生产运行/候选工件记录Stage结果，向独立签发服务提交候选引用和证据；如果当前无等价申请队列，则在工程阶段经库表审查后最小补建，**申请不等于签发**。
2. Reviewer以独立受控身份向签发入口发起审核；签发入口通过DB可信会话/最小专用角色验证Reviewer身份和该G对应资格，禁止服务端共享特权账号以Producer身份假冒；作品发布Reviewer与Operator均不能复用该接口直接产生专业G资格。
3. 单事务内按上述精确键锁定当前投影，验证确切版本、purpose、scope、consumer、dependency、证据、时间及原Gate专业政策；通过时只追加`gate_audits`新记录并CAS写投影；未通过只记录真实HOLD/REJECT，不将调用者指定PASS直接持久化。
4. 失败在历史追加或投影更新任何一步时整事务回滚；对重复请求使用受控幂等标识，确保不发生两个同时生效的资格投影。撤权增加独立裁决/状态并立即阻断读入口，不改旧历史事件；缓存发布端按有效资格重验。
5. 未来工程迁移按 `预检→扩展列/可选投影→旧行分类标识legacy→双路径只读校验→切断旧Gate写权限→迁移Reader→回归→授权切换`；旧PASS只作历史证据，**不得自动转成新资格PASS**。回滚不得恢复旧Producer签发权限，也不得复活已撤销知识公开许可。

### C1-C｜明确定义未证的物理前置，而不是笼统“等数据库再说”

- **已证而可形成设计的事实**：基础表主键、运行FK、旧唯一键已DROP、资格扩展列类型、六阶段枚举、生产者直接UPDATE/INSERT、imported_materials的owner列、资格JSON结构。上述已进入本合同并可供后续工程实施者定向开发。
- **静态源码仍需补证**：全迁移序列的GRANT/REVOKE、历史`gate_audits`其他消费者、`public.users`与auth会话的实际映射、运行时数据库凭证注入方式、现有等价资格投影是否存在。缺项明确按路径逐项取证，不能用待验证三个字替代。
- **只能工程时从生产库获证**：现时`pg_roles/pg_auth_members/role_table_grants/pg_policies`、行数量与真实视图依赖、签发密钥、在线部署版本、RLS效果与事务并发负测。必须工程恢复后独立预检；当前不允许写可直接运行的盲猜 SQL，也不因此否认设计合同中已固定的目标字段和权能。
- **设计准出残余**：需逐项确定 `qualification_current` 是否确需新增、真实旧调用方改造路径、角色凭证分离、回退与索引设计；这些在未定前C1只能`PARTIAL_TARGET`,不能升格为`K3_DESIGN_VERIFIED`。


### C1-D｜真实数据库连接与自建认证对权限实施的约束

已核`apps/web/lib/auth.ts@10186ead`使用自建HMAC session、`public.users@f84c7fde`为用户主表、`apps/web/app/api/studio/materials/import/route.ts@973bc0e8`以`session.uid`控制导入表Owner、`packages/data-access/src/index.mjs@d3f8ebc0`以`DATABASE_URL`驱动psql或node-pg。因而实际运行中 **`auth.uid()` 不一定等于、也不一定能读取 `public.users.user_id`**；任何最终权限设计必须先明确可信身份桥接与独立连接主体。业务层Owner谓词是现有保护，不能代替数据库GRANT/RLS。Reviewer不与Producer共用具有Gate写权限的连接池身份；跨事务SET身份必须以数据库可信约束证明不会被生产Agent伪造。此项将原来模糊的“身份映射待查”缩减为**自建HMAC→数据库可信身份的目标接口与分权工作**，仍未在运行环境实测。


### C1-E｜36份现有SQL的角色/Policy源级盘点与最小迁移包责任

对固定提交`supabase/migrations/`36份既存SQL进行只读筛查：没有发现显式`GRANT/REVOKE`、DB角色创建或`SECURITY DEFINER`定义；`202610280900_publication_work_revisions.sql`包含仅按pointer存在或`status=published`的两条只读Policy，多表只有`ENABLE RLS`。这说明**既有迁移文件尚不能单独提供完整角色授权契约**，不是远端实际权限结论。必须新增**一份经真实预检后才可执行的有界迁移**作为目标文件身份，覆盖Gate签发/投影、共享连接分权、imported_materials合法会话读写及作品撤权后的G5/版权公开Guard；不得重复定义原物理表、不得盲目回放历史DDL。该未来SQL仍需在`K3-C4`取得唯一目标文件路径与hash，不能把本概念段落视为DDL已完成。


## K3-C1｜Registry原路径最小源码候选与实施前置（2026-10-31续核）

现行 `registry.mjs@df41d29d62521380599918767d1f8e2bc1b41b07` 未执行Schema校验；`orchestrator.mjs@ce0a61cba2cb04d913213461d558c82545421ffa` 在执行前未核job启用；`persistence-contract.mjs@1e995392d65bf94855923c241026e78e8bffdfed` 仅按Schema允许各D阶段操作所有`control.*`。已形成Library中**三个原路径完整候选**（非当前工程）：

- `pipelines/data-production/orchestrator/registry.mjs`：引用原唯一V4 Schema，以Ajv2020校验、核六阶段对应、draft禁止启用、独立Reviewer绑定核查；设计态可只读装载，不得执行。
- `pipelines/data-production/orchestrator/orchestrator.mjs`：保持`STAGE_ORDER`、resume和`STAGE_CONTRACTS`既有交接，仅在`loadExecutor()`之前加入逐Job、mode、审核绑定和受托权限核验，默认拒绝；**具体校验改成原Registry Loader内部验证Ed25519签名的Stage限定许可（只向生产运行时提供公钥），另由独立DB实时HOLD/jti复核器承担撤权和重放拒绝；该DB复核器与独立授权签发服务尚未实现**。
- `pipelines/data-production/adapters/persistence-contract.mjs`：保留各Stage业务Schema，同时`control.production_runs`允许受控运行记账，生产者对`gate_audits`及未来资格投影的任何正式写入操作均失败关闭；此静态方法不能取代DB凭据分离，也挡不住绕过该helper的直连SQL。

**前置依赖**：V4 JSON Schema必须通过现有完整Registry实例和六阶段正反样本；Target `package.json`仅候选加入`ajv`运行依赖，未来受控工程迁移须同步pnpm lockfile并安装校验。必须把可信执行授权服务与数据库最小权限实装并正反验证后，才能宣称Loader/Stage实际可安全运行；否则保持所有Stage disabled。不新增并行Registry、第二个Orchestrator或Skill体系。

**离线设计核查**：上述三个目标JS通过`node --check`语法检查；`persistence-contract.mjs`7个操作授权正反样例通过（仅此helper的逻辑模拟）；未在GitHub固定提交完整依赖下执行Node测试、未真实装载全部Registry、未授权DB模拟、未执行线上E2E，状态`TARGET_SOURCE_CANDIDATE / DESIGN_NOT_FULLY_VERIFIED / ENGINEERING_NOT_RUN`。


## K3-C1｜独立Gate物理迁移的两阶段DDL蓝图与原子签发接口（仍非可直接运行SQL）

以下蓝图**仅针对旧迁移已证明的真实列**，不另建资格历史表，不重放带`DROP VIEW CASCADE`的旧迁移，也不修改库中现有历史行。**这是目标字段/操作级签收依据，必须在工程隔离环境完成`pg_catalog`预检后转成带编号迁移SQL**；未授权不得执行。所需信息中，不属于当前仓库可证明的`pg_roles/GRANT/SECURITY DEFINER/线上行数`作为工程预检保留，但不能免除以下设计不变量。

### 1. 只读预检SQL（第一阶段必须形成有权限的回执）

```sql
-- K3 design-only examples, do not paste into production migration without Owner authorization.
SELECT current_user, session_user, current_database();
SELECT n.nspname, c.relname, c.relkind, c.relrowsecurity, c.relforcerowsecurity,
       pg_get_userbyid(c.relowner) AS table_owner
FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
WHERE (n.nspname,c.relname) IN (('control','gate_audits'),
 ('control','production_runs'),('public','imported_materials'),('public','conversations'));
SELECT table_schema,table_name,grantee,privilege_type
FROM information_schema.role_table_grants
WHERE (table_schema='control' AND table_name IN ('gate_audits','production_runs'))
 OR (table_schema='public' AND table_name IN ('imported_materials','conversations'));
SELECT schemaname,tablename,policyname,roles,cmd,qual,with_check
FROM pg_policies WHERE (schemaname='control' AND tablename='gate_audits')
 OR (schemaname='public' AND tablename IN ('imported_materials','conversations'));
SELECT p.proname,n.nspname, p.prosecdef, pg_get_userbyid(p.proowner) AS function_owner
FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
WHERE n.nspname IN ('control','public') AND p.prosecdef;
```

附加必须验证：当前已应用迁移列表、主键/外键/触发器、旧current_valid写者、每条审计行数与有效分布、`gate_audits`所有视图/服务消费者，及`DATABASE_URL`真实连接角色、是否拥有BYPASSRLS/表Owner、对外Data API直接访问范围。**固定GitHub旧DDL与真实环境可能不同，差异一律优先修正设计而非假定线上一致。**

### 2. 物理差分（Phase-A：仅扩展、默认旧数据为legacy、不开通新写权）

已知 `control.gate_audits` 的唯一历史主键`gate_audit_id`及run外键不得改变。增加以下列作为**新合格决定的可选列**，保持旧行可读：`artifact_revision text`、`purpose_namespace text`、`purpose_code text`、`purpose_version text`、`reviewer_id text`、`reviewer_role text`、`reviewer_proof_ref text`、`valid_from timestamptz`、`valid_until timestamptz`、`long_term_basis jsonb`、`evidence_refs jsonb`、`qualification_record_kind text NOT NULL DEFAULT 'legacy_unverified'`、`signature_request_id uuid`、`scope_digest text`、`dependency_digest text`。现有`result`五态、`rule_version`、`supersedes_id`、`allowed_scope`、`consumer`和`dependency_snapshot`复用，非空/强制数组不直接施加到历史行。

新增约束仅约束`qualification_record_kind='independent_signed_v1'`的记录：`artifact_revision`/三个purpose字段/`reviewer_id`/`reviewer_proof_ref`/`consumer`/`rule_version`非空，`reviewer_role='independent-gate-reviewer'`，`jsonb_typeof(dependency_snapshot)='array'`，`jsonb_typeof(allowed_scope)='object'`且非空。若`result='PASS'`，还必须`valid_from`和至少1条`evidence_refs`且具`valid_until`或非空`long_term_basis`，不可将旧记录默认升级。

**必要且只允许一个当前状态投影**：先用预检找是否已有等价表/视图/索引；确无则新建`control.qualification_current`，唯一键由`(gate_code,object_type,object_id,artifact_revision,purpose_namespace,purpose_code,purpose_version,scope_digest,consumer,dependency_digest)`构成，唯一关联指向已存在的`gate_audits.gate_audit_id`；状态字段为`current_status`、`projection_version`、`updated_at`。对Scope与依赖采用明确版本的跨语言JSON规范化与SHA256（低写权限角色不得自行提交未经核验的digest）。**投影不是裁决历史，也不自行赋予资格**：每次公开读取都必须确认当前时效、依赖和用途。

### 3. 物理角色与签发事务（Phase-B：经全流程回归后才切换）

部署时必须明确至少三个互不等权的实际DB身份：生产进度/候选身份（只写其允许D阶段及`production_runs`）、独立Reviewer签发身份（可通过受控接口追加资格并CAS投影，但不可编辑历史）、受限消费者身份（只按严格用途/Scope返回知识分面）。Operator作品审核身份不得获得独立G签发能力。角色名应以系统已存在角色/Owner准出的新部署凭据确定；绝不能沿用同一高权`DATABASE_URL`号称分权。

受托签发入口目标API应当接收：`decision_request_id`、`run_id`、`gate`、`artifact_ref{type,id,revision}`、`purpose{namespace,code,version}`、`allowed_scope`、`consumer`、`dependency_snapshot`、`rule_version`、`evidence_refs`、`decision`、`reason_codes`、`expected_projection_version`；**reviewer身份必须由可信服务会话/独立DB连接取得，不能接受请求body伪造**。事务：核有效Reviewer与Gate权限→核证据/权利/对象revision/依赖快照→锁定规范化资格键（首次插入也应有事务级键锁或唯一冲突重试）→严格按专业规则得出决定→向旧`gate_audits`追加不可变新行→对`qualification_current` CAS更新→COMMIT，任何一步失败全部ROLLBACK。`decision_request_id`需要唯一幂等性，重复请求原样回执或明确冲突，不得重复资格有效化。

切换前必须迁移旧读取器：`recordGate`/`writeGate`只提交候选，不再写正式PASS；`passed/legalInput`、`read-model-bridge`、`retrieveMaterials`、作品发布与公开证据端统一通过当前资格判断；旧`current_valid`仅为legacy兼容，不可充当新签发事实。切换成功、所有老写者拒绝并经测试之后，才能禁止对`independent_signed_v1`审计行UPDATE/DELETE，保留旧历史只读。失败回退只允许关闭新入口、保留历史和有效已签资格，不准恢复Producer自签或复活已撤销的旧PASS。

### 4. 一对一验收边界（设计完备不等于运行通过）

- `C1-DB-01`旧字段/视图/依赖清单与源迁移逐列无损；`C1-DB-02` Producer不能INSERT/UPDATE/DELETE正式资格；`C1-DB-03` Reviewer凭据真实独立且不能由其他调用者SET ROLE或伪装；`C1-DB-04` 同资格键重复/并发裁决/撤权只出现一个当前合法指针，历史均保全。
- `C1-DB-05` 历史无revision/reviewer/purpose版本的旧PASS只能标`legacy_unverified`；`C1-DB-06` 作用域/消费者/过期/依赖变化必须fail closed；`C1-DB-07` 中途异常不能出现半签发；`C1-DB-08` Gate撤销后公开API/缓存/旧发布指针不能重新消费。
- `C1-DB-09` `imported_materials`合法用户仍能导入但匿名/跨用户拒绝；`C1-DB-10` `conversations`增加Owner后旧无主数据不能被任意用户用已知ID读取；`C1-DB-11` 登录状态和角色撤销后旧HMAC令牌的敏感路由访问全部拒绝；`C1-DB-12` 不误伤D00—D05合法生产进度和历史数据恢复。

**当前状态：`SOURCE_DDL_MAPPED / TARGET_PHYSICAL_SEMANTICS_DESIGNED / EXECUTABLE_MIGRATION_AND_DB_ROLE_ATTESTATION_NOT_DONE`**。不可因为有本节就将SEC-01或独立G资格工程HOLD销项；K3下阶段仍须补受控签发服务、G0—G5读取守卫与可执行迁移的静态完整性。


### C1授权令牌的防伪增强（本轮精确目标差分）

`registry.mjs`原路径源码候选取消了可由调用者传入、返回`true`即可绕过的`verifyExecutionAuthority()`，改为在Runner进程**只持有公钥**的Ed25519/JWS形式签名校验：固定`typ=MOHEN-STAGE, alg=EdDSA, kid=mohen-stage-v1`；claims必须匹配`run_id,stage,job_id,mode,architecture_generation,iss,aud,iat,exp,jti`及`execution_policy.enable_requires`，有效期不得超过300秒。每个Stage加载Executor前仍必须有**来自独立受控服务**的`verifyLiveHoldAndNonce`，在真实DB内核当前工程授权/HOLD/重放与失效epoch。该回调不能由浏览器或Studio/Producer用户自行提供；未来实际运行集成时必须硬编码绑定受信服务，并结合生产DB最小权限，否则禁止启用Job。

设计测试：伪签名/错误算法/跨run/跨job/跨stage/超时/缺HOLD状态均拒绝；签名合法且实时受控授权通过才可进入Executor；即使伪造Context回调也不能凭空生成合法签名。签发私钥**不得与生产进程、Studio、Operator、通用DATABASE_URL共享**。代码只通过静态语法检查，密钥发行/轮换/重放事务以及集成测试仍为明确的C1目标缺口。

**授权候选局部动态验证（隔离模拟）**：从目标`registry.mjs`原样提取`assertStageExecutionAuthorized`逻辑，使用临时Ed25519密钥验证有效签名、跨stage、跨run、过期、条件缺失、设计态禁执行、Reviewer绑定未核、实时HOLD拒绝和伪造签名9例，`9/9`得到预期结果。该测试**没有**载入真实V4 Registry、Ajv依赖、受信的DB实时HOLD/nonce服务，也不证明工程中攻击者不能注入回调；因此`K3-C1_PARTIAL_TARGET`保持。


## C1-DB｜2026-10-31 Supabase项目当前物理目录只读核验（**真实元数据已取得**）

**来源边界**：对当前已连接`mohen-cloud` PostgreSQL 17实例仅用Supabase只读`list_tables`及`SELECT`查询`information_schema.columns/role_table_grants`、`pg_roles`、`pg_class`、`pg_policies`、`pg_constraint`。未访问用户业务行或密钥、未执行任意DDL/DML、未调整服务配置。它证明当前元数据，不替代未来切换时再次预检，也不意味着已通过写入/并发/真实请求验证。

1. `control.gate_audits`是真实存在的六门资格历史表，现有主键`gate_audit_id`、FK `run_id→production_runs`、FK `supersedes_id→gate_audits`；CHECK明确`D00—D05/G0—G5`，表RLS=true、Owner=`postgres`、`force_rls=false`。目录显示**约711条历史审计**，因此已有历史必须严格保留。其物理列与原`202610160300`迁移相符，仍是`purpose text/current_valid boolean/dependency_snapshot jsonb`而无独立签发身份、对象修订、版本化purpose等目标字段；目标`control.qualification_current`目前不存在。物理差分现已通过当前Schema确认，不再笼统称“没有查到线上表”。
2. `pg_roles`中`postgres`可登录且`rolbypassrls=true`；`anon`/`authenticated`不可登录且`rolbypassrls=false`；`service_role`本身具有bypassrls。按本轮查询，**不存在名为`mohen%`的专用DB角色**。`control.gate_audits`目前显示`postgres`有SELECT/INSERT/UPDATE/DELETE等表级权限，未见`anon`/`authenticated`直接表级权限。**不能由此确定实际Node或CLI使用哪个DATABASE_URL登录**，但已经证明独立Producer/Reviewer数据库身份尚无专用项目角色可直接复用。
3. `public.imported_materials`真表有`owner_user_id uuid NOT NULL`引用`public.users`，`RLS=false`、`force_rls=false`、`postgres`为Owner；`anon/authenticated`都拥有SELECT/INSERT/UPDATE/DELETE及其他表权限且没有RLS Policy；平台安全Advisor也报告该表RLS禁用为**critical**。目录当前显示0行。**SEC-01已由旧静态风险升级为LIVE_CATALOG_CONFIRMED_CRITICAL**，正式工程恢复前必须设计修复，但此阶段严禁直接执行`ALTER TABLE`：如直接启用RLS且不给合法后端路径配套策略，将可能阻断导入。
4. `public.conversations` RLS=true，存在约1行，仍**没有owner_user_id**；有anon/authenticated表级GRANT，但查到的`pg_policies`未列出该表Policy，按普通非Owner角色RLS默认拒绝；`postgres`可绕过RLS。源API-033只查登录与ID，所以**服务端自建HMAC后端DB路径存在必须整改的资源Owner缺失**；不能把RLS已启用误当整条API已安全。
5. `publication.published_pointers`、`publication.work_revisions`的RLS=true；当前两个Policy分别为`published_pointers_public_read USING(true)`和`work_revisions_published_read USING(status='published')`。即使它们当前不一定获得anon对非public schema的访问GRANT，也不能据此把专业G5/版权/撤权作为当前合法判断；应用读路径仍须明确。未授权工程不得直接开宽GRANT或移除现有作品发布服务。

**对应唯一目标收敛**：新的Gate角色与签发事务须在独立迁移中有界创建；严格限制旧`postgres`服务凭据作为Producer通用登录，Reviewer身份与独立签发入口需DB可验证的真正分权；`imported_materials`按“先核自建会话→后端受限身份与Owner过滤→RLS/GRANT定向收紧→正常导入与匿名/跨用户负测→切换”实施。`conversations`必须先保留1条旧行并识别归属，后增owner及严格存取，未知归属不自动绑定。历史资格711条不自动晋级、不能清空。`qualification_current`仍为按实际不存在之证据支持的最小`CREATE_IF_GAP`设计候选。

**已消除的K3信息缺口**：旧表实际存在、列/约束、基础GRANT、RLS状态、Owner/BYPASSRLS角色、已知视图/Policy存在性及目录行数。**仍是设计HOLD**的：真实应用`DATABASE_URL`使用主体/签发私钥的可靠隔离、迁移SQL/函数身份最终实现、完整Guard消费者分面与负测、运行时在线验证。仅保留后者，不再以“所有线上元数据不可获取”为笼统阻断。


**当前迁移历史补核（只读）**：Supabase连接返回的`list_migrations`为空列表，而数据库物理表/字段显然存在且与仓库若干迁移相符。这**不证明历史SQL没有执行**，仅证明不能用该接口取得已应用迁移的可靠流水。未来工程切换前须通过合法的`supabase_migrations.schema_migrations`结构/库内对象/仓库提交差异核准实际迁移基线，防止重放破坏性旧脚本。安全顾问还报告约52张表“RLS启用但无Policy”（INFO）：通常意味着低权角色默认拒绝，而非自动数据泄露；结合服务器实际数据库角色是否绕过RLS分别审查，不将Advisor数量当安全合格率。

## K3-C1｜可实施的最小物理迁移与独立资格签发合同（2026-10-31设计补齐；未运行）

> **基线**：现有`control.gate_audits`有711行历史审计；含六门但`purpose text`、`current_valid boolean`，缺独立reviewer/object revision/typed purpose；现有`control.qualification_current`不存在；生产Adapter、Repository、治理Gate Writer可直接 UPDATE/INSERT `gate_audits`。本节提出**工程迁移目标，不是迁移已经执行**。改造保持原`control.gate_audits`历史行及原D/L/G专业语义，不允许清空、重建、自动晋级历史PASS。

### 迁移步骤与依赖（必须依次执行；每步有原子回退）

1. **PREFLIGHT只读**：固定实际Git提交与迁移顺序，导出完整schema-only/角色/ACL/RLS/依赖/视图/函数签名与哈希；记录旧711审计行数及主键集合SHA和`production_runs`行数；比对生产用户连接`current_user/session_user/rolbypassrls`，不记录密码。由于`list_migrations`为空而物理表存在，禁止直接重放全量历史迁移。
2. **安全优先冻结**：在不修改历史事实的条件下先处理`public.imported_materials`匿名暴露：停止任何面向浏览器的低权限直接表访问，按已有自建HMAC后端导入通道做受限后端角色；目标事务先REVOKE anon/authenticated对表CRUD、再ENABLE RLS，服务端当前`postgres`连接若绕过RLS不得拿该结果当权限通过。负例验证通过后开放导入。对`conversations`必须先隔离旧无主记录，禁止自动归属于任一用户。
3. **ADD-ONLY物理扩展**：保留旧审计表；新建`control.gate_candidates`（生产候选）及`control.qualification_current`（经过独立签发的当前资格指针），为`gate_audits`追加可空、受严格CHECK的签发字段，旧行默认为`legacy_untrusted`。新增正确的角色/权限，生产角色不得INSERT/UPDATE/DELETE正式审计与当前指针；应用读角色只可查经资格/用途/时点筛选的受限视图或授权函数。
4. **写读双轨隔离**：原`layer1-adapters.mjs`/`data-production-repository.mjs`的`recordGate`改写入`gate_candidates`，**不得再变更`gate_audits.current_valid`**。原`governance-gate.ts`仅保留作品审批兼容身份，不得自写G5；作品审核与专业独立签发是不同动作。所有读取`gate_audits`并按`result='PASS' AND current_valid=true`作资格授权的旧消费者，必须切到`qualification_current`联动`gate_audits`的合法当前投影。任何未迁移消费者必须返回HOLD而不是继续旧PASS。
5. **单独的签发与撤权事务**：Gate Reviewer使用单独LOGIN和DB连接、独立证书/密钥，只接受被核准的候选+typed artifact revision+purpose(namespace/code/version)+scope+consumer+dependency_snapshot+有效期/永久复核依据。一个串行化事务内，锁定同一资格键→验证全部上游当前资格、依赖、权利、Rule版本、独立Reviewer角色→追加`gate_audits`新签发事件→CAS置换`qualification_current`唯一指针→提交。REVOKE也是追加正式决策事件并原子删除/替换当前可消费指针；旧事件仍在，不准反向升级。
6. **原子切换与撤销**：旧消费者禁用→所有新消费者通过资格矩阵正反/撤权/并发/时点/跨身份测试→切换。回滚只能关闭新授权读写和切回仍经过安全过滤的旧路径；如旧路径资格不可证明，保持HOLD，绝不恢复旧`current_valid`的自动通行。

### 必要目标DDL字段级身份（迁移SQL须经未来执行工具生成并校验依赖，不允许直接对生产执行下方示意片段）

`control.gate_audits`保留原列，追加 `candidate_id uuid nullable references control.gate_candidates`、`artifact_revision text nullable`、`purpose_namespace text nullable`、`purpose_code text nullable`、`purpose_version text nullable`、`reviewer_user_id uuid nullable references public.users`、`reviewer_db_identity text nullable`、`decision_origin text NOT NULL DEFAULT 'legacy_untrusted' CHECK IN ('legacy_untrusted','independent_gate')`、`valid_from timestamptz nullable`、`valid_until timestamptz nullable`、`long_term_basis jsonb nullable`、`qualification_digest text nullable`、`signed_at timestamptz nullable`；新独立PASS必须由独立事务强制检查以上必需字段、签发身份、证据引用、scope、依赖、目的和生效区间；历史行**不补假身份**。

`control.gate_candidates`目标字段：`candidate_id uuid PK`、`run_id uuid FK`、`stage text CHECK D00..D05`、`gate_code text CHECK G0..G5`、`object_type text`、`object_id uuid`、`artifact_revision text NOT NULL`、`purpose_namespace/code/version text NOT NULL`、`allowed_scope jsonb`、`consumer text`、`dependency_snapshot jsonb`、`evidence_refs jsonb`、`input_fingerprint text`、`submitted_at timestamptz`、`producer_identity text`、`candidate_status text CHECK (SUBMITTED,HOLD,REJECTED,CONSUMED)`；禁止Producer在候选表直接写正式PASS/Reviewer身份。

`control.qualification_current`目标字段：`architecture_generation text`、`gate_code text`、`object_type text`、`object_id uuid`、`artifact_revision text`、`purpose_namespace text`、`purpose_code text`、`purpose_version text`、`consumer text`、`gate_audit_id uuid NOT NULL REFERENCES control.gate_audits`、`valid_from timestamptz`、`valid_until timestamptz`、`dependency_fingerprint text NOT NULL`、`scope_digest text NOT NULL`、`rule_version text NOT NULL`、`reviewer_user_id uuid NOT NULL`；**复合主键为前九字段**。所有目标列非空，`qualified PASS`只由该表与正式审计的联结、当前有效时间、最新依赖及撤权epoch联合确定；单独审计PASS不是消费许可。

### DB角色与最小权限矩阵（未来工程候选，而非当前grant事实）

- `mohen_producer`：独立LOGIN，`NOSUPERUSER NOBYPASSRLS NOINHERIT`；只获得所属D层资产最小读取/写入、`gate_candidates INSERT`、`production_runs`受限状态操作；**没有**`gate_audits`和`qualification_current`写权限，不能被授予`postgres/service_role`密码、`SET ROLE`或继承审核角色。
- `mohen_gate_signer`：独立LOGIN，`NOSUPERUSER NOBYPASSRLS NOINHERIT`；只允许经审批的资格签发事务，新增正式审计和当前指针修改须单事务；无法执行业务生产D00—D05。身份核验不能只凭HTTP角色声明，签发来源应有不可伪造审计。
- `mohen_app_runtime`：后台自建HMAC角色的受限DB连接，只进行明确授权的Owner读写、合法作品发布及资格消费；不能写正式专业Gate，不以`auth.uid()`假定本项目身份。开放Data API的`anon/authenticated`不授予受限素材/私有对话写权限。
- `postgres`/`service_role`：保留迁移/恢复专用，**禁止继续作为所有API与生产的共享日常执行身份**；DB owner bypassrls时任何RLS测试均必须用真实低权限角色复测。

### 不可缺少的交叉负例（设计断言；未来工程执行）

`GSQL-01` Producer直接INSERT/UPDATE Gate审计与当前指针必拒绝；`GSQL-02` Producer伪造Reviewer、替换DB连接或伪造签名必拒绝；`GSQL-03` 711条历史行迁移前后主键、行数、原字段快照不变，旧PASS不自动进入新当前指针；`GSQL-04` 当前资格版本/purpose/consumer/scope错配拒绝；`GSQL-05` 上游撤权/证据变化及旧缓存拒绝；`GSQL-06` 并发签发仅一个合法当前指针，旧事件永存；`GSQL-07` 用户跨Owner访问、禁用后旧会话拒绝；`GSQL-08` 匿名浏览器对`imported_materials`的读写全部拒绝且本人后端导入仍正常；`GSQL-09` 应用/资格/DB中途异常一律回滚，不能返回PASS。附带`GSQL-10`未知旧对话Owner行不得自动分配用户，`GSQL-11`公开修订失效后WATCH/EXP/证据页面不返回缓存内容。

**C1结论限定**：物理事实已获只读目录证据，字段与角色职责设计已明确；但签发事务SQL、生产执行者持久连接、变更文件命名和逐执行路径的集成实现尚未完成，只有后续真实工程授权才能运行/证明。不得把本节的SQL蓝图报为生产DDL已部署。

### C1-PHYSICAL｜工程审核用最小增量DDL草案（**仅Library设计稿；禁止直接执行**）

下方是依2026-10-31只读`pg_catalog/information_schema`确认的**现有表与字段**撰写的增量SQL骨架，用于后续Codex生成真实Migration、隔离测试与权限审查。不存在的签发服务、生产连接角色/秘钥、历史数据处理必须先满足上一节前置条件；不能把该代码块作为已部署DDL或无条件“一键执行”。实际实施时必须先用CLI创建正式迁移文件并对目标实例静态Diff、备份和回滚演练。

```sql
-- K3 DESIGN ONLY, NOT EXECUTED. Phase A: additive, preserve all old audits.
BEGIN;
CREATE TABLE IF NOT EXISTS control.gate_candidates (
  candidate_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  run_id uuid NOT NULL REFERENCES control.production_runs(run_id),
  stage text NOT NULL CHECK(stage IN ('D00','D01','D02','D03','D04','D05')),
  gate_code text NOT NULL CHECK(gate_code IN ('G0','G1','G2','G3','G4','G5')),
  object_type text NOT NULL,
  object_id uuid NOT NULL,
  artifact_revision text NOT NULL CHECK(length(artifact_revision)>0),
  purpose_namespace text NOT NULL CHECK(length(purpose_namespace)>0),
  purpose_code text NOT NULL CHECK(length(purpose_code)>0),
  purpose_version text NOT NULL CHECK(length(purpose_version)>0),
  consumer text NOT NULL CHECK(length(consumer)>0),
  allowed_scope jsonb NOT NULL,
  dependency_snapshot jsonb NOT NULL,
  evidence_refs jsonb NOT NULL DEFAULT '[]'::jsonb,
  input_fingerprint text NOT NULL,
  producer_identity text NOT NULL,
  candidate_status text NOT NULL DEFAULT 'SUBMITTED'
    CHECK(candidate_status IN ('SUBMITTED','HOLD','REJECTED','CONSUMED')),
  submitted_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE control.gate_audits
  ADD COLUMN IF NOT EXISTS candidate_id uuid REFERENCES control.gate_candidates(candidate_id),
  ADD COLUMN IF NOT EXISTS artifact_revision text,
  ADD COLUMN IF NOT EXISTS purpose_namespace text,
  ADD COLUMN IF NOT EXISTS purpose_code text,
  ADD COLUMN IF NOT EXISTS purpose_version text,
  ADD COLUMN IF NOT EXISTS reviewer_user_id uuid REFERENCES public.users(user_id),
  ADD COLUMN IF NOT EXISTS reviewer_db_identity text,
  ADD COLUMN IF NOT EXISTS decision_origin text NOT NULL DEFAULT 'legacy_untrusted',
  ADD COLUMN IF NOT EXISTS valid_from timestamptz,
  ADD COLUMN IF NOT EXISTS valid_until timestamptz,
  ADD COLUMN IF NOT EXISTS long_term_basis jsonb,
  ADD COLUMN IF NOT EXISTS qualification_digest text,
  ADD COLUMN IF NOT EXISTS signed_at timestamptz;
ALTER TABLE control.gate_audits
  ADD CONSTRAINT k3_decision_origin_check
  CHECK (decision_origin IN ('legacy_untrusted','independent_gate')) NOT VALID;
-- Prior to VALIDATE CONSTRAINT, inspect duplicates and preexisting naming collisions.
CREATE TABLE IF NOT EXISTS control.qualification_current (
  architecture_generation text NOT NULL,
  gate_code text NOT NULL CHECK(gate_code IN ('G0','G1','G2','G3','G4','G5')),
  object_type text NOT NULL,
  object_id uuid NOT NULL,
  artifact_revision text NOT NULL,
  purpose_namespace text NOT NULL,
  purpose_code text NOT NULL,
  purpose_version text NOT NULL,
  consumer text NOT NULL,
  gate_audit_id uuid NOT NULL REFERENCES control.gate_audits(gate_audit_id),
  valid_from timestamptz NOT NULL,
  valid_until timestamptz,
  dependency_fingerprint text NOT NULL,
  scope_digest text NOT NULL,
  rule_version text NOT NULL,
  reviewer_user_id uuid NOT NULL REFERENCES public.users(user_id),
  PRIMARY KEY (architecture_generation,gate_code,object_type,object_id,
               artifact_revision,purpose_namespace,purpose_code,purpose_version,consumer),
  CHECK(valid_until IS NULL OR valid_until > valid_from)
);
ALTER TABLE control.gate_candidates ENABLE ROW LEVEL SECURITY;
ALTER TABLE control.gate_audits ENABLE ROW LEVEL SECURITY;
ALTER TABLE control.qualification_current ENABLE ROW LEVEL SECURITY;
-- Note: app-side DB role currently unknown; do not switch sources before role tests.
COMMIT;
```

**Phase B角色候选**（由具DDL授权的迁移主体执行，须先设置互不继承的登录凭据与机密，不得由应用Node获取超管角色；实际表权限按业务D层白名单再精炼）：

```sql
-- DESIGN ONLY. Must not use postgres/service_role for routine app/producer requests.
CREATE ROLE mohen_producer LOGIN NOSUPERUSER NOBYPASSRLS NOINHERIT;
CREATE ROLE mohen_gate_signer LOGIN NOSUPERUSER NOBYPASSRLS NOINHERIT;
CREATE ROLE mohen_app_runtime LOGIN NOSUPERUSER NOBYPASSRLS NOINHERIT;
GRANT USAGE ON SCHEMA control TO mohen_producer, mohen_gate_signer, mohen_app_runtime;
GRANT SELECT ON control.production_runs TO mohen_producer, mohen_gate_signer;
GRANT SELECT, INSERT ON control.gate_candidates TO mohen_producer;
GRANT SELECT, UPDATE(candidate_status) ON control.gate_candidates TO mohen_gate_signer;
GRANT SELECT, INSERT ON control.gate_audits TO mohen_gate_signer;
GRANT SELECT, INSERT, UPDATE, DELETE ON control.qualification_current TO mohen_gate_signer;
GRANT SELECT ON control.qualification_current TO mohen_producer, mohen_app_runtime;
-- RLS is enabled; explicit, role-specific policies are required or every
-- low-privilege operation will default-deny even with GRANT. Such denial
-- must not be "fixed" by switching the runtime connection to postgres.
CREATE POLICY k3_candidate_producer_submit ON control.gate_candidates
  FOR INSERT TO mohen_producer WITH CHECK (producer_identity = current_user);
CREATE POLICY k3_candidate_signer_read ON control.gate_candidates
  FOR SELECT TO mohen_gate_signer USING (true);
CREATE POLICY k3_candidate_signer_update ON control.gate_candidates
  FOR UPDATE TO mohen_gate_signer USING (true) WITH CHECK (candidate_status IN ('SUBMITTED','HOLD','REJECTED','CONSUMED'));
CREATE POLICY k3_audit_signer_insert ON control.gate_audits
  FOR INSERT TO mohen_gate_signer WITH CHECK
  (decision_origin = 'independent_gate' AND reviewer_db_identity = current_user);
CREATE POLICY k3_current_signer_all ON control.qualification_current
  FOR ALL TO mohen_gate_signer USING (true) WITH CHECK (true);
CREATE POLICY k3_current_producer_read ON control.qualification_current
  FOR SELECT TO mohen_producer USING (true);
CREATE POLICY k3_current_app_read ON control.qualification_current
  FOR SELECT TO mohen_app_runtime USING (true);
-- Qualified scopes and consumer/rights still require application request-level
-- authorization and live qualification checking; table RLS alone is not enough.
-- Not granted: producer write to gate_audits or qualification_current;
-- no client anon/auth direct rights to Gate professional tables.
REVOKE ALL ON public.imported_materials FROM anon, authenticated;
ALTER TABLE public.imported_materials ENABLE ROW LEVEL SECURITY;
-- Restricted backend role has only authorized owner-scoped read/insert; detailed
-- DB policies follow physical verified authentication design, not auth.uid().
```

**修正约束**：以上角色SQL只写必要权限基线，不代表Producer能用上述语句独立运行全部D00—D05；Stage实际的D层表权限需按既有`OWNERSHIP_MAP`与Repository实际SQL逐表校验并补齐，不能授权全部schema写入。`qualification_current`具有复合PK但必须由Signer服务内单事务严格检查审计事件的`decision_origin='independent_gate'`、`result='PASS'`、对象修订与同一purpose/scope/consumer/Rule/Reviewer以及依赖和时效；仅FK无法实现完整史学资格判断。`gate_audits`应增加仅Signer可调用的签发入口及不可变事件触发保护（现有旧记录允许静态读取，不可编辑），历史`current_valid`只作为兼容旧事实而非新资格。`GRANT`/`REVOKE`不替代直接的低权限用户实测与撤权验证。

## K3-C1｜Studio对话资源归属与公开史料RLS：确定性物理Diff（仅设计，未执行）

**源证据**：固定提交 `202610290100_fine_capabilities.sql@031348903bb13fdf037b443eeaac55334b43ee66` 创建 `public.conversations(conversation_id uuid,title text,messages jsonb,created_at,updated_at)` 且无 `owner_user_id`；2026-10-31真实 Supabase 只读目录确认表存在且存量1条，RLS ENABLE但无Policy，`anon/authenticated`表级广泛GRANT。`public.imported_materials`有owner但RLS DISABLED、GRANT广泛（无业务数据行）；该环境元数据不代表其它环境。

**Phase-A确定性扩展DDL草案：**

```sql
-- DESIGN ONLY. Generate CLI migration and test against exact catalog before execution.
BEGIN;
ALTER TABLE public.conversations
  ADD COLUMN IF NOT EXISTS owner_user_id uuid REFERENCES public.users(user_id);
CREATE INDEX IF NOT EXISTS k3_conversations_owner_created_idx
  ON public.conversations(owner_user_id,created_at DESC);
REVOKE ALL ON TABLE public.conversations FROM anon,authenticated;
REVOKE ALL ON TABLE public.imported_materials FROM anon,authenticated;
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.imported_materials ENABLE ROW LEVEL SECURITY;
COMMIT;
```

**Phase-B临界约束**：现存 `public.conversations` 未知Owner行保持 `NULL` 并禁止 API 返回、修改、自动分配；由有身份来源的独立迁移核实后才允许回填。自建HMAC用户**不是** Supabase `auth.uid()`；必须以 `apps/web/lib/session.ts` 服务端现查 `public.users` 的active身份，经 `fine-capabilities.ts` SQL `WHERE owner_user_id=:'uid'::uuid` 执行，未来App数据库连接必须使用非BYPASSRLS最小角色。在建立完整低权限连接和会话绑定之前不直接开放新的Data API policies；`RLS ENABLE`+无Policy+`GRANT REVOKE` 为拒绝直连防线，不是后台Owner隔离的全部保证。

**必须有的正反证据**：`DB-OWNER-01` 当前用户创建返回新UUID，`owner_user_id`落库；`DB-OWNER-02` 自己历史对话可见、他人UUID为404；`DB-OWNER-03` 存量空Owner不自动归属/不返回；`DB-OWNER-04` anon/authenticated直接SELECT/INSERT/UPDATE/DELETE全部失败；`DB-OWNER-05` 禁用账户与旧HMAC角色立即失效；`DB-OWNER-06` 并发消息更新不覆盖；`DB-OWNER-07` 导入材料Owner流程功能仍可用且匿名读写拒绝；`DB-OWNER-08` 撤权及负面G5消费不被已发布缓存突破。工程未运行，所有测试均`ENGINEERING_NOT_RUN`。

**回滚**：如新认证回归失败，关闭相关私人对话API并保留新增Owner列与旧历史行，不以撤销RLS/重新授予anon访问作为回退；仅将新执行器和路由切回仍通过Owner防线的旧实现，不可回到旧未隔离读取。此步骤在真实迁移中必须有明确测试和角色绑定。

## K3-C1/C2｜真实通知字段复用与WATCH观看状态主键重构的两阶段SQL（设计，不执行）

**已证当前物理事实**：`public.notifications(id uuid PK,user_ref text NOT NULL,type,title,body,read,created_at)`，故**不要新增通知Owner列**，`API-022`以自建会话`session.uid`字符串匹配`user_ref`即可；同时复核其它消息产生者的`user_ref`编码。`public.watch_sessions(work_id uuid PRIMARY KEY,playhead numeric,updated_at)`，当前约2条历史行，不能确定Owner，旧数据保留但不得迁移时自动认领。

```sql
-- DESIGN ONLY: two-stage additive + controlled key transition (not applied).
-- Phase A: add, non destructive; retain legacy work_id PK for now.
ALTER TABLE public.watch_sessions ADD COLUMN IF NOT EXISTS watch_session_id uuid DEFAULT gen_random_uuid();
ALTER TABLE public.watch_sessions ADD COLUMN IF NOT EXISTS owner_user_id uuid REFERENCES public.users(user_id);
ALTER TABLE public.watch_sessions ADD COLUMN IF NOT EXISTS revision_id uuid REFERENCES publication.work_revisions(revision_id);
-- Phase B (only after old row isolation and new writer rolled out atomically):
-- historic work_id PK must be dropped only when live transactions and constraints are checked.
ALTER TABLE public.watch_sessions ALTER COLUMN watch_session_id SET NOT NULL;
ALTER TABLE public.watch_sessions DROP CONSTRAINT watch_sessions_pkey;
ALTER TABLE public.watch_sessions ADD CONSTRAINT watch_sessions_pkey PRIMARY KEY (watch_session_id);
CREATE UNIQUE INDEX k3_watch_owned_revision_unique ON public.watch_sessions(owner_user_id,work_id,revision_id)
  WHERE owner_user_id IS NOT NULL AND revision_id IS NOT NULL;
REVOKE ALL ON TABLE public.watch_sessions FROM anon,authenticated;
ALTER TABLE public.watch_sessions ENABLE ROW LEVEL SECURITY;
-- Do not add PUBLIC client policies. Server minimum role must enforce owner in every SELECT/UPSERT.
```

**强制前置/回滚**：Phase-B不单独执行，上线切换必须先验证新写入服务和两类用户身份、表依赖/历史索引及并发，且不可在无事务原子切换下丢旧PK；历史NULL Owner/Revision行原封不动但不可读取到任何账户；新访问需检查合法发布指针、作品版本和权利撤销。失败时禁用新持久化、使用游客本地播放状态并停止公共数据库写入，不复活旧共享work_id数据。`WATCH-01` A/B不同用户播放进度隔离；`WATCH-02`同用户不同修订独立；`WATCH-03`旧无归属行不可见；`WATCH-04`游客不写表；`WATCH-05`过期/撤权作品不返回残留；`WATCH-06`重复/并发写事务唯一、失败回滚。


### K3定向物理设计：导演方案归属作品（API-045）

真实catalog确认 `public.director_plans` 有 `owner_user_id uuid NULL`，但**无 `work_id`**；旧路由`apps/web/app/api/studio/works/[id]/stages/route.ts@0bb845c4b490882f31fa8dbb1192b1e1239522f4` 的导演方案SQL仅 `JOIN public.research_tasks t ON t.work_id=:wid`，未连接 `d` 与作品，可能返回其它人的/其它作品的导演方案，造成跨作品信息泄漏。

**未来迁移，先于应用发布，禁止在本设计审阅阶段执行：**

```sql
ALTER TABLE public.director_plans
 ADD COLUMN IF NOT EXISTS work_id uuid REFERENCES publication.works(work_id);
CREATE INDEX IF NOT EXISTS k3_director_plans_work_id_idx ON public.director_plans(work_id) WHERE work_id IS NOT NULL;
```

- 更改既有 `apps/web/lib/studio-director.ts` `createDirectorPlan(...,ownerUserId,workId?)`：使用来自会话授权核查过的 `workId` 入库，不信任UI直接赋主；传入workId时明确验证 `publication.works.owner_user_id`，运营代创须审计；没传workId的独立草案保留`NULL`但不在作品进度中出现。
- 更改既有 `apps/web/app/api/studio/director-plans/route.ts`：仅允许`work_id`在已`canAccess('publication.works', workId, session.uid, isOperatorSession(session))`下传递；关联创建必须原子化、不得跨Owner；发回计划独立归属。
- 同路径目标 `repo_target/apps/web/app/api/studio/works/[id]/stages/route.ts` 只查询 `d.work_id=:wid`；不从旧brief/topic猜Owner，不自动回填旧`director_plans`行。未来由明确有据的work/plan关联人工/受控恢复。
- 正反验收：两个作品各有不同方案，GET只返回各自方案；多研究任务不重复计划；他人/匿名拒绝；未知历史NULL方案不可通过猜测曝光；先扩字段，再producer与route同版本部署，必要时关闭进度显示回滚，保留历史数据。


## KAD1-B/R4.3｜受权业务合同到持久层的唯一补充映射（2026-11-02，DESIGN_ONLY）

- 资产、修订、跨run引用、Research/Work双产物、知识/作品分离等语义唯一在`specs/KNOWLEDGE_ASSET_LIFECYCLE_CONTRACT.md`。本文件只定义真实数据库Repo写入顺序、行权、原子性、索引及备份。
- G0—G5独立审查的规则唯一在`specs/data-production/gates/G0-G5_MACHINE_GATE_CONTRACT_V3.0.md`；此文件负责生产写候选与独立签发事务的物理分权。
- 最新main已含K3独立Gate SQL和仓储；本文件先于任何实库迁移要求按最新SHA三方核对SQL/GRANT/RLS、旧711行保护、资格真实生效及回滚。不得把2026-10-31草案直接当尚未施工、也不能因SQL存在宣布已激活。

## KAD1-E｜确定性最小迁移目标

新增202611020900复用watch_sessions：增加不可变watch_session_id主键及owner_user_id/revision_id，旧无主行保留不可领取；部分唯一索引保护用户/作品/修订，Owner RLS和签名DB上下文联合验证。202611020910只增加消费阻断与检查，不修改已签审计；202611020920串行化账户/角色变更，最后角色和签名当前身份在同事务内验证。三份对应rollback关闭新写入/公开消费但保留数据、阻断与审计，不恢复不合法旧路径。现有三项K3迁移保持原样；依赖安装顺序及角色/密钥配置须在KAD4隔离/真实环境分别验证。

## KAD6完整物理存储绑定：九层主数据、12候选表、原件与零权限默认（唯一物理Owner）

### 责任边界与新增表完整去重

本节是在原现行数据库与KAD4设计研究基础上的**施工目标字段合同（DESIGN_ONLY）**，不是可在生产库直接执行的SQL。禁止复制第二套D01`read_units`、L3Truth、L5读模型、作品或原Gate表。新候选**12张表（11业务+1Gate候选）**可在工程读到已有同义能力后ADAPT缩减，**不可未经反查直接扩建12张**。

| L层/功能 | 首选已有权威主表（KEEP/ADAPT）或有界CREATE | 主键/关键依赖与保持条件 |
|---|---|---|
| L0 | `source.sources/source_versions/raw_items` | source_id/source_version_id/raw_item_id；真实私有原件对象、SHA-256、版本与分动作rights；`storage_ref`不足以证明已存 |
| L1 | `source.read_runs/source.read_units` | `read_runs.raw_item_id→raw_items`；typed locator/read_run/method/config/hash/G1；可页图回放 |
| L2 | `evidence.reading_units/material_evidence/read_unit_evidence_links` | `evidence.reading_units`仅D02材料结构；唯一D01真源`source.read_units`经G1/证据桥，非平行OCR库 |
| L3 | `world.entities/events/relation_claims/claim_revisions/claim_evidence_links/changes` | 主张到L2 evidence→L1→L0，时地精度及冲突/依赖；不按名称猜FK |
| L4 | `meaning.findings/claim_revisions/present_connections/open_questions` | 有据人文解释和当下端，G4独立于L3事实 |
| L5 | 六类现存`read_model.*` | 只产生派生消费投影，版本/依赖/资格/权限绑定，不能造第七真值库 |
| L6 | `experience.runtime_sessions`与`experience.runtime_events`（CREATE候选） | 运行状态/动作、修订与隐私期限；旧`public.watch_sessions/explore_sessions`仅兼容，非公众无限日志 |
| L7 | `participation.contributions`（CREATE候选） | `contribution_series_id+consent_revision_no`、同意撤回追加记录，点击不成史料 |
| L8 | `culture.trace_candidates`（CREATE候选） | `trace_series_id+trace_revision_no`、来源同意及D00再入请求，不直接写L3 |

其余CREATE候选恰为：`studio.projects(project_id,owner_user_id,scope)`、`studio.asset_heads(asset_id,project_id,asset_kind,current_revision_id)`、`studio.asset_revisions(revision_id,asset_id,revision_no,supersedes_revision_id,origin_task_snapshot,content_hash,rights,source_refs,dependency_refs,idempotency_key)`、`studio.asset_links(link_id,source_revision_id,target_kind,target_ref,target_revision_ref,link_role,rights_decision_ref)`、`studio.delegations(delegation_id,project_id,root_task_ref,root_task_snapshot,delegation_series_id,delegation_revision_no,request_hash,idempotency_key,allowed_actions,transfer_rights_decision)`、`studio.execution_receipts(receipt_id,delegation_id,attempt_no,request_hash,result_manifest,acceptance_state,cost)`、`studio.use_events(use_event_id,project_id,ref@revision,consumer,purpose,action,rights_decision)`、`control.gate_candidates(candidate_id,run_id,stage,gate_code,artifact_revision,purpose_namespace/code/version,allowed_scope,consumer,dependency_snapshot,evidence_refs,input_fingerprint)`。**8项 + L6两项 + L7一项 + L8一项 = 12候选**；与既有表逐名去重后确定最终可执行迁移。

### 事务、外键及不可丢失的不变量

1. `studio.projects.owner_user_id`与`public.users`关联，避免项目/任务的`ON DELETE CASCADE`导致资产丢失；FK优先`ON DELETE RESTRICT`，首期只能合法Owner操作；`project_id`不是可让外部AI任意给定的字符串。历史task/work不按题名猜测所属项目，映射未知时隔离待审核。跨项目授权对来源项目与目标项目分别验证。
2. `studio.asset_revisions`不可变；`(asset_id,revision_no)`唯一，`asset_heads.current_revision_id`带**同asset身份复合FK**且只用CAS提交。`supersedes_revision_id`必须由服务/触发器确认属于同asset，不能只凭普通FK。任务级可删FK只能`ON DELETE SET NULL`，另保留合法最小`origin_task_snapshot`；跨run引用不删除。
3. `studio.delegations`的幂等约束必须为`(project_id,root_task_ref,idempotency_key)`，而非可清空的`root_task_id`；每个执行尝试的`(delegation_id,attempt_no)`唯一，回执只追加。收包/原件保存和SQL不是跨系统单事务：先登记PENDING→上传→服务器回读校验→STORED_VERIFIED，失败留补偿、孤儿对象回收、不可误标SUCCESS。
4. 多态的`studio.asset_links.target_kind/ref/revision`必须服务端依目标类型校验实际存在和关联权限；专用`source.read_unit→evidence.read_unit_evidence_links→evidence.material_evidence→world.claim_evidence_links`保证跨层引用可返查。实际空表不以设计DDL自动填充。
5. `control.gate_candidates`是**当前main源码已写但实际库未建**的候选提交表，只允许Producer写候选。独立Reviewer审`control.gate_audits`、动态`purpose/scope/consumer/action/policy/effective/dependency`资格；需按当前真实迁移去重，保护历史审计，旧PASS不得自动升级。

### 原件、备份、安全和施工目标验收

- 先用只读目录核既有`source.raw_items.storage_ref/checksum_sha256`与真实Storage对象可用性；**指针存在不是文件存在**。私有bucket候选`raw/{source_id}/{source_version_id}/{raw_item_id}/{sha256}`不可覆盖；原文件、派生识读、许可元数据分离。签URL按操作/Actor/项目+短时效，严格即时撤权场景使用逐请求代理，不能声称已签URL会即时失效。
- **双向可恢复备份**：同`backup_id`封存DB一致快照、对象列表/字节与SHA、Policy/rights版本、文件locator、Schema与恢复步骤；恢复后默认不开放公开阅读、不自动激活Gate，重核项目ACL/权限/对象字节和撤权。只备份数据库不是完整恢复。
- 安全阻断：`public.imported_materials`当前RLS关闭，anon持SELECT/INSERT表级权限，属工程SEC-P0；分角色撤直接能力并建立符合现行会话/服务身份的最小导入流程，**不能**只执行`ENABLE RLS`导致合法导入断路或凭服务角色绕行无鉴权。
- **未来隔离正反测试**：项目归属/跨账号；CAS双提交/被删task；Storage实际回读/hash/bbox；G候选与Reviewer DB隔离；L1→L2→L3真实桥；WATCH撤权；备份与恢复；迁移回滚。此次KAD6只签设计字段与验收责任，不运行PG/改变GRANT。
