# 墨痕｜工程基础与现行规范导航（MHKA目标代际候选，不在GitHub生效）

> `target_generation: mhka.v1` · `status: DESIGN_CANDIDATE_NOT_APPLIED` · `physical_path: specs/FOUNDATION.md`
>
> **文件职责由旧“三层架构权威”转为单一工程导航**。本文件不重新定义产品使命、Skill、史学知识层号、数据事实、运行部署或独立资格，也不能覆盖现行 `AGENTS.md`。

## 1. 阅读路径

实际生效后的新会话先读 `CURRENT.md`（运行事实和HOLD），再读 `AGENTS.md`（唯一Authority版本路由）及 `OWNERSHIP_MAP.md`（目录职责），然后按任务定位一至数份 MHKA-00—05 及唯一专业合同。设计期仍以现有工程入口为准，**不得依据本候选路径切换**。

## 2. 单一权威清单

- 角色、版本/变更、准入：MHKA-00；战略/公众价值：MHKA-01；HOME/Studio/WATCH/EXP/Admin用户能力：MHKA-02。
- 历史知识、L0—L8/资格语义：MHKA-03；D00—D05方法/Agent/Skill/Gate专业职责：MHKA-04；技术边界/权限/测试/部署：MHKA-05。
- 原D/L/G专业算法与审核证据：`specs/data-production/standards/d00—d05`及其受授权专业合同（专业细则不因MHKA改写）。
- 生产编排：`specs/data-production/MoHen_Data_Production_Protocol.md`；唯一机器Gate规则：`specs/data-production/gates/gate-contracts.v3.json`（正式激活待验证）。
- 逻辑/物理/调用：`specs/DATA_CONTRACT.md`、`specs/data-production/PERSISTENCE_BINDING_CONTRACT.md`、本文件§3的运行/调用索引（非第二份SAD）。
- Agent和体验运行：`specs/AGENT_CONTRACT.md`、`specs/EXPERIENCE_CONTRACT.md`。规格/Registry引用上游，不得与MHKA另立相同规则。

## 3. 现行运行结构与调用导航（与独立运行拓扑合同分责）

**本节仅为工程模块阅读导航。** `specs/SYSTEM_RUNTIME_ARCHITECTURE.md`是已纳入本代目标集合的运行拓扑及调用合同，按MHKA-05限定软件调用关系；两者不得重复定义历史知识、权限、资格或产品价值。本节不得否定已收录的下游合同。

| 现有模块/代码位置 | 真实职责 | 新合同落点与未解阻断 |
|---|---|---|
| `apps/web/app/api/**/route.ts` 与 `apps/web/lib` | Studio/运营/WATCH/EXP等请求/作品管理/鉴权 | `specs/API_TOOL_CONTRACT.md`；GET/POST具体字段和资源角色逐接口核验 |
| `packages/agent-runtime/`、`packages/experience-engine/` | 意图/选择与体验状态、Patch/Replan | `AGENT_CONTRACT`与`EXPERIENCE_CONTRACT`；知识用途与体验效果不能相互授权 |
| `pipelines/data-production/run.mjs`、`orchestrator/`、`executors/`、`adapters/` | 单一六阶段生产与方法执行 | 生产Protocol+Registry+Gate v3；Adapter直写Gate仍HOLD |
| `packages/data-access/`、`supabase/migrations/` | 数据访问、六L5读模型、历史迁移 | `DATA_CONTRACT`/持久化合同；Schema/GRANT/RLS与SEC-01需回归 |
| `.github/workflows/`、`tests/`、`verification/`、`specs/OPERATIONS_DEPLOYMENT.md` | 构建、测试、旧验收与部署运维 | K3需求追溯索引+真实环境回归；历史PASS非U07全部PASS |

设计记录（含上述代码至合同的具体图谱）放K3总览报告，不再建立另一份定义上位架构的新文档。`AGENTS`路由、`CURRENT`现行状态与`OWNERSHIP_MAP`职责持续分别为唯一真实入口。

## 4. 旧规范的隔离

此前 `FOUNDATION.md` 的“Agent Action Layer / Agent Runtime / 三层架构”只能作为旧代际历史背景。其 `L4 Trusted Read Model` 或 `L5 Experience Runtime` 等编号，均不得用于当前六阶段代际。历史编号与实际实现细节通过正式替代/迁移记录追溯，归档旧正文不得删除。

## 5. 文件生效

没有 `MHKA` 决策签发、合同代际一致性、机器路由更新、运行回归以及Owner工程授权，本文件只是K3目标设计候选。`DESIGN_PASS` 不等于 `RUNTIME_APPLIED`，也不意味着任何真实Gate或内容获得公开消费资格。


## 6｜KAD1-A—E新架构下位专业规则唯一工程路径（待原子激活）

| 研究编号 | 本代唯一专业执行入口 | 上位权威 |
|---|---|---|
| KAD1-A | `specs/data-production/MoHen_Data_Production_Protocol.md` §11 | MHKA-03/04 |
| KAD1-B | `specs/data-production/gates/G0-G5_MACHINE_GATE_CONTRACT_V3.0.md` | MHKA-00/03/04 |
| KAD1-C | `specs/experience-ui/H1_H2_H3_AND_COMPONENTS_CONTRACT.md` | MHKA-02/04 |
| KAD1-D | `specs/AGENT_PROFESSIONAL_CAPABILITIES_CONTRACT.md` | MHKA-04 |
| R4.3 | `specs/KNOWLEDGE_ASSET_LIFECYCLE_CONTRACT.md` | MHKA-03 |

`AGENT_CONTRACT`与`EXPERIENCE_CONTRACT`只负责机器边界；`PERSISTENCE_BINDING_CONTRACT`与`SECURITY_ACCESS_CONTRACT`负责物理实现。旧专项KAD1-A/B/C/D标题不再是下游工程文件，原研究稿保留历史证据。

## 7｜KAD1-E完整机器与运行入口

- `specs/SYSTEM_RUNTIME_ARCHITECTURE.md`：当前模块、持久化、资格与恢复调用关系。
- `skills/README_DATA_PRODUCTION_SKILLS.md`及六Stage/七共享SKILL：19身份的现行设计绑定。
- `specs/requirements/TRACEABILITY_INDEX.md`及85API/152动作CSV：本代规范与当前源码/未来验收。
- `specs/data-production/method-binding-contract.json`与production-registry.json：63方法和六Job；新增绑定不激活执行。
- `specs/OPERATIONS_DEPLOYMENT.md`与工程交接合同：启用、备份、回滚及授权边界。
