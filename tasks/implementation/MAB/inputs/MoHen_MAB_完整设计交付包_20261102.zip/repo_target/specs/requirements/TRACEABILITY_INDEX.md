# 墨痕 K3 需求与工程证据追溯

Owner于2026-10-31批准按增量施工计划实施。当前为本地工程迁移，未激活MHKA、未更新生产权限或部署。原AGENTS路由继续有效。

## 唯一需求输入

- `api-route-contracts.csv`：85个候选API的请求、响应、权限、事务和正反测试要求。
- `u07-action-contracts.csv`：五图62模块、152动作及真实/目标handler证据边界。
- 输入包：`MoHen_Codex_K3_增量设计迁移输入包_20261031.zip`，两个CSV与包内同名repo_target文件字节一致；输入不是实现回执。
- 保留API既有成功wire与逐ID明确例外，不以通用HTTP/字段模板覆盖已证行为。

## 状态与检查

执行 `node scripts/guards/check-k3-traceability.mjs` 核验身份唯一、覆盖、源码路径和设计handler证据；这不是85API或152动作运行验收。

四种证明分别维护：设计要求、源码可定位、隔离测试、真实投运。表中的 `ENGINEERING_NOT_RUN` 必须在对应运行证据产生后才能变更；不能因目标handler已命名而报已实现。

57字段和104项设计处置的输入身份、支持文件及批次状态见 `tasks/implementation/K3/README.md`。真实执行回执见 `tasks/results/` 对应K3报告；不把审查矩阵复制成第二套API或动作规范。

## 保留阻断

MHKA-00包内正文与K4审查指纹不一致，正式激活等待审定；H1/H2/H3正式原文和完整442/41验收原表尚缺。其余安全与原位工程整改继续；专业方法和完整产品准出不能凭摘要签发。

## 2026-11-01 创作投稿合同的最小兼容增量

原85条输入账及历史source blob保留，不以本节重算ID。API-080与既有`/api/works/:id/submit`继续接受已验证的无正文调用，服务端只解析一次最新修订后精确提交该修订；新Studio客户端显式传`revision_id`。原成功`ok:true`保留，增补`work_id/revision_id/status:'submitted'`回执。指定修订不可提交为409，正文非法为400，存储不可用为503；不能零更新后恒返成功。创建作品原`work_id`成功字段保留，增补实际初始`revision_id`。

这是已批准创作正确性目标下的技术修复，不引入新的公开发布动作。测试见`tests/unit/publication-submission.test.ts`、`submission-routes.test.ts`、`tests/integration/submission-revisions.integration.ts`和既有五图E2E增量；隔离与真实投运证据仍分账。不得将这些用例通过提升为全部创作或知识资格验收完成。

独立审查后的创建正确性补充：`/api/works`支持可选`creation_id`。新Studio在同一草稿重试时复用该ID；作品与初始修订由同一SQL原子创建并直接返回身份。已有ID仅在Owner、初始标题和内容匹配时幂等返回，冲突为409；原调用方省略该字段仍由服务端生成身份。等待回执期间禁止改变待交草稿；完整跨刷新恢复仍属后续Studio任务，不将当前挂载会话的幂等重试冒称跨设备恢复。

## KAD1-E本代输入与历史阻断校准

本代基线main@db21cefcc09c6bcb5d7e3fca16d100cc0accd13d，两份CSV保留85 API、152动作、62模块和五画面，原source/测试/兼容列不删除。新增KAD1列是当前源码引用、方法/导入/守卫观察、规范消费者与实施阶段；不是运行验收。API-X01的路径字段已规范为精确仓库路径。
六MHKA完整正文与H/I方法、资产及能力合同已在repo_target对应规范路径归位；前文关于MHKA-00指纹和H1/H2/H3未随旧包提供的文字描述历史包限制，不再用来要求下游读取旧包作为新规范前提。当前唯一正文为governance/mhka、`specs/experience-ui/H1_H2_H3_AND_COMPONENTS_CONTRACT.md`、`specs/AGENT_PROFESSIONAL_CAPABILITIES_CONTRACT.md`、`specs/KNOWLEDGE_ASSET_LIFECYCLE_CONTRACT.md`、`specs/data-production/MoHen_Data_Production_Protocol.md`、`specs/data-production/gates/G0-G5_MACHINE_GATE_CONTRACT_V3.0.md`。
机器输入→规范→源码→正反测试可反查；源码存在不代权限和资格验证。EXP完整功能延后，Studio/Admin优先，WATCH消费同一合法作品修订。实现或运行HOLD留在各行，不因本次归位转PASS。

## KAD6｜完整设计集成新增强制追溯横轴与最终双向门

| 追溯轴 | 唯一规范来源 | 机器目标和证据 | 设计PASS拒绝条件 |
|---|---|---|---|
| KAD2内外AI混合与Studio | `AGENT_CONTRACT`,`AGENT_PROFESSIONAL_CAPABILITIES_CONTRACT`,`KNOWLEDGE_ASSET_LIFECYCLE_CONTRACT` | 受控委托/回执、T1—T7候选、13资产与Studio ST01—09 | 首题无真实两主体分工、临时日志当永久账、无权限外发 |
| KAD3 Admin/WATCH | `EXPERIENCE_CONTRACT`,`API_TOOL_CONTRACT` | F05内部`AdminAuthorizedItemViewV1`、WATCH同一作品版次/动态Guard | 独立知识平台、仅统计无条目、仅published跳过G |
| KAD4九层/Storage与Gate | `DATA_CONTRACT`,`PERSISTENCE_BINDING_CONTRACT`,`SECURITY_ACCESS_CONTRACT`,`Gate V3` | 9层主表组、12表候选去重、原件hash+locator、项目ACL、Gate候选与独立审计 | source.read_units重复Truth、无字节却标存储、Producer签G、过期PASS公开 |
| KAD5真实双题验收设计 | 本代Knowledge/Agent/Experience/Production/Operations各完整条款 | A隋唐大运河→B宋代江南运河城镇的真实工程回执、修订复用及新有据知识 | 仅设计脚本被标LIVE；重复摘要冒增长；没有第二题权限审查 |

正式交接要求旧 `85` API 和 `152` U07动作逐行绑定该表上位职责与具体文件，保留原ID、不把新内部service强行算成已存在公开路由。逐行文件Hash、编译/实库实测均需另行证据；KAD6只对目标合同做正反静态审查，不签运行PASS。
