# MoHen Agent Contract｜MHKA代际目标候选

> `status: DESIGN_CANDIDATE_NOT_APPLIED` · `generation: mhka.v1` · `file_owner: MHKA-05`（接口机器契约）
> 上位职责：MHKA-02（产品行为）、MHKA-03（数据与资格语义）、MHKA-04（Agent和工具专业责任）。此处只规定Agent软件调用边界，不重新发明方法算法或史学Truth。

## 1. 适用范围

Agent运行于四个授权上下文之一：`CTX-ENG`、`CTX-PROD`、`CTX-STUDIO`、`CTX-EXPLORE`。CTX是授权执行情境，不是独立Skill家族，也不是同名产品页面。每次请求须提供受信任身份、项目、意图、用途、来源数据权限、预算、环境、请求ID及可审计调用链。最终公开观看只从合法消费路径进入，不能将Studio内部读权限携入公开会话。

## 2. 两条不同的读取合同（不能再称旧 L4 Trusted Read Model）

### A. 公开知识消费 / WATCH 与 EXP

默认只读取**当前有效的 L5可信发布分面**及已获合法发布的作品版本。要求上游G0—G5相应资格及来源/版本/用途/范围/消费者/时效满足消费者请求。Agent文本引用与视觉舞台图片展示的合法用途应分别判定。若权限、权利、时效或依赖链不完整，明确返回 `HOLD/BLOCKED` 及相关引用，不能退回冻结Demo/旧PASS缓存。

### B. 内部Studio受托研究

Studio在有效项目授权、来源许可、研究用途、敏感限制、审计和预算内，可以**持续受控读取合法的L0—L4研究资料**及适用的L5分面，无须把研究候选先提升到G5、也无须每次合法读取重复人工许可。这一入口只能返回研究材料或候选及其认识/用途标签；不能直接公开展示或写正式Truth，不能绕过D/L/G/独立Gate，并与公众缓存/搜索通道隔离。

两入口既不共用未标用途的缓存，也不以数据库服务账号权限扩大用户授权。

## 3. Agent任务循环与产物分流

`目标与角色校验→检索既有资产/合法外部来源→工具计划→预算预留→Tool/Skill/Production Tool受控执行→结果校验→证据和权利标引→候选交付→必要时向原D00—D05生产系统提交请求→独立Gate审核/合法分面→人文导演/作品编辑→观察与Replan`。

必须分别保有研究候选、D/L正式资产、Gate资格、作品修订、公开发布指针和会话状态，不能一个 `status=done` 代表全链均成功。无资料、模型失败、工具越权、预算不足、版权不明和Gate拒绝时返回可继续补证的状态，不能凭模型生成段落补齐事实。

## 4. 专业调用与权限

- Agent有计划、搜索、工具选择和**提出生产候选/申请**的权利，不得直接写正式 L0—L5 Truth 或 Gate PASS。
- `Production Tool` 是经项目授权调原有 `pipelines/data-production/run.mjs`/受控队列的**唯一正式生产入口**；禁止为Studio另建第二条Truth生产链。
- 原生产 Stage Owner（D00—D05）保留对应L成果唯一写入责任。`create-stage-executor` 的流程PASS不能成为独立G签发。
- Reviewer/Operator/Creator角色不因同一人兼任而默认相互授予资格；作品审核与史学资格独立。
- 旧Developer/Agent Skill身份保持兼容；六Stage与现行活动清单的5/6差异在真实Registry/Skill/Executor核验后才能解除；未经验证不批量重命名。

## 5. Evidence on Demand与结果表达

公众可由当前合法L5依赖回溯经L4（有解释时）/L3→L2→L1→L0的合法位置和证据。不允许旧协议中以“L4 Trusted Read Model”为始点的编号假设。没有完整依赖只能返还实际有效部分和受阻原因，不能补造引文、坐标或历史图像。

## 6. 失败、撤权及成本

每次Tool Call至少保留 `request_id`、执行上下文、项目/资源、工具/模型标识、权限决策、预算、阶段、结果引用、错误原因、重试条件与中止原因。真实字段名称/端点仍待K3机器字段级冻结。已撤权资源应在权限Guard即时阻断相关消费者，再由独立Gate追加专业裁决；过期缓存不可恢复。Studio外部工具若无授权或可能把受限资料泄露给第三方，应立即HOLD。

## 7. 与真实代码的兼容及验收

已有 `packages/agent-runtime/`、`apps/web/lib/mohen-agent/research.ts`、`apps/web/lib/studio-research.ts`、`apps/web/lib/studio-production.ts` 应优先复用。当前 `child_process.spawn` 触发生产有实现，但不等于已证明云端持久/超时/中断恢复。未来必须验证：合法Studio底层研究读、公开越权失败、生产Agent不得自签Gate、预算/外部工具拒绝、素材欠缺、不完整证据、作品与知识双资产状态及撤权缓存。

**激活规则：** 这是代际替换候选；只有工程恢复获Owner授权、实测通过并在 `AGENTS.md` 与真实实现同时切换后生效。原V2.0依代际归档，不存在新旧两个ACTIVE Agent Contract。


## 8｜本代Agent专业方法合同的唯一职责边界（KAD1-D镜像必需）

- R4/CAP、63方法、19 Skill、模型路由、Agent预算/补证/撤权业务规则的唯一细则：`specs/AGENT_PROFESSIONAL_CAPABILITIES_CONTRACT.md`；本文件只拥有Agent读写入口和权限边界。
- 不允许Agent/外部AI直接提升知识资格。工具选择、Task/Skill可用性与实际调用必须经Runtime Registry/授权判定；KAD1-D静态设计不等于工具已经接线。
- 核查未来源码和原有`specs/data-production/method-binding-contract.json`；能力定义、方法绑定、执行证据分别标`DESIGN_ONLY/CODE_PRESENT/VERIFIED_*`，禁止用文档存在替代运行。

## 9｜KAD2混合研究任务与项目授权资产服务绑定（KAD6）

- 一次根任务：`root_task_id/project_id/creator/goal/budget_policy`；内部Agent真实按项目搜索旧资产、拆出带依赖的Plan DAG、先复用再确定性Tool/专业Tool/有界外部模型，逐子任务有`delegation_id/request_hash/receipt_id`，按`lease_epoch/idempotency`阻止重复副作用。不能把原一条`runResearch()`调用或复制外部答案视为混合协同完成。
- 分包前检查`actor/active_project+源资产@rev/用途/许可的external_transfer与模型处理动作/provider/保留期/预算/expiry`。外部回包隔离并按T1—T7逐item验schema、实际来源文件、权利、原文与解释、同源、时地、当前资格；接收为Studio研究候选rev或返回拒绝/补证，不直接写正式`world/meaning/read_model/gate_audits`。
- D00仅目录线索、D01无原件locator、D02同源/推断未核、G未签/方法未绑定时可保存受限候选与WorkDraft，明确`SOURCE_BIBLIO_ONLY/LOCATOR_MISSING/WAITING_GATE/NOT_CONNECTED`；不显示假完成。Agent的公开L5阅读与Studio项目内合法L0—L4读取是两个独立消费能力，权限不能互借。
- 第二题精确复用第一题`A_asset_id@revision`与有权L@rev，记录使用与新增证据，不重复摘要冒知识增长；KAD5官方双题题目见本代Knowledge与专业验收合同。真实执行、模型/Tool版本、RLS、Gate和Storage仍待工程验证。
